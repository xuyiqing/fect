## Matrix Completion for Interactive Fixed Effects Models
## (fect: fixed effects counterfactuals)
## Version 1.01
## Author: Yiqing Xu, University of California, San Diego
## Date: 2018.1.20

## MAIN FUNCTION
## fect.formula()
## fect.default()

## DEPENDENT FUNCTIONS
## fect.fe()
## fect.mc()
## fect.boot()

## METHODS
## print.fect()
## plot.fect()


#####################################################################
## A Shell Function
#####################################################################

## generic function

fect <- function(formula = NULL, data, # a data frame (long-form)
                 Y, # outcome
                 D, # treatment 
                 X = NULL, # time-varying covariates
                 na.rm = FALSE, # remove missing values
                 index, # c(unit, time) indicators
                 force = "unit", # fixed effects demeaning
                 r = 0, # nubmer of factors
                 lambda = NULL, # mc method: regularization parameter
                 nlambda = 10, ## mc method: regularization parameter
                 CV = TRUE, # cross-validation
                 k = 5, # times of CV
                 method = "fe", # method: fe for interactive fe; mc for matrix completion
                 se = FALSE, # report uncertainties
                 nboots = 200, # number of bootstraps
                 parallel = FALSE, # parallel computing
                 cores = NULL, # number of cores
                 tol = 0.001, # tolerance level
                 seed = NULL, # set seed
                 min.T0 = 5, # minimum T0
                 max.missing = NULL, # maximum missing
                 pre.period = NULL, # fit test period 
                 fitBoot = "wild", # wild or nonpara
                 fitTest = FALSE, # fit test
                 placebo.period = NULL, # placebo test period
                 placebo.start = NULL, # placebo test period start point
                 placeboTest = FALSE, # placebo test
                 normalize = FALSE # accelerate option
                ) {
    UseMethod("fect")
}

## formula method

fect.formula <- function(formula = NULL,data, # a data frame (long-form)
                         Y, # outcome
                         D, # treatment 
                         X = NULL, # time-varying covariates
                         na.rm = FALSE, # remove missing values
                         index, # c(unit, time) indicators
                         force = "unit", # fixed effects demeaning
                         r = 0, # nubmer of factors
                         lambda = NULL, # mc method: regularization parameter
                         nlambda = 10, ## mc method: regularization parameter
                         CV = TRUE, # cross-validation
                         k = 5, # times of CV
                         method = "fe", # method: fe for interactive fe; mc for matrix completion
                         se = FALSE, # report uncertainties
                         nboots = 200, # number of bootstraps
                         parallel = FALSE, # parallel computing
                         cores = NULL, # number of cores
                         tol = 0.001, # tolerance level
                         seed = NULL, # set seed
                         min.T0 = 5,
                         max.missing = NULL,
                         pre.period = NULL,
                         fitBoot = "wild", # wild or nonpara
                         fitTest = FALSE,
                         placebo.period = NULL,
                         placebo.start = NULL,
                         placeboTest = FALSE,
                         normalize = FALSE
                        ) {
    ## parsing
    varnames <- all.vars(formula)
    Yname <- varnames[1]
    Dname <- varnames[2]
    if (length(varnames) > 2) {
        Xname <- varnames[3:length(varnames)]
    } else {
        Xname <- NULL
    }
    ## run the model
    out <- fect.default(formula = NULL, data = data, Y = Yname,
                        D = Dname, X = Xname,
                        na.rm, index, force, r, lambda, nlambda, 
                        CV, k, method, se, nboots,
                        parallel, cores, tol, seed, min.T0,
                        max.missing, pre.period, fitBoot, fitTest,
                        placebo.period, placebo.start, 
                        placeboTest, normalize)
    
    out$call <- match.call()
    out$formula <- formula
    ## print(out)
    return(out)

}

## default function

fect.default <- function(formula = NULL, data, # a data frame (long-form)
                         Y, # outcome
                         D, # treatment 
                         X = NULL, # time-varying covariates
                         na.rm = FALSE, # remove missing values
                         index, # c(unit, time) indicators
                         force = "unit", # fixed effects demeaning
                         r = 0, # nubmer of factors
                         lambda = NULL, ## mc method: regularization parameter
                         nlambda = 0, ## mc method: regularization parameter
                         CV = TRUE, # cross-validation
                         k = 5, # times of CV
                         method = "fe", # method: fe for interactive fe; mc for matrix completion
                         se = FALSE, # report uncertainties
                         nboots = 200, # number of bootstraps
                         parallel = FALSE, # parallel computing
                         cores = NULL, # number of cores
                         tol = 0.001, # tolerance level
                         seed = NULL, # set seed
                         min.T0 = 5,
                         max.missing = NULL,
                         pre.period = NULL,
                         fitBoot = "wild", # wild or nonpara
                         fitTest = FALSE,
                         placebo.period = NULL,
                         placebo.start = NULL,
                         placeboTest = FALSE,
                         normalize = FALSE
                        ) {  
    
    ##-------------------------------##
    ## Checking Parameters
    ##-------------------------------## 
    ## library(ggplot2)

    if (is.data.frame(data) == FALSE) {
        data <- as.data.frame(data)
        warning("Not a data frame.")
    }
    ## index
    if (length(index) != 2 | sum(index %in% colnames(data)) != 2) {
        stop("\"index\" option misspecified. Try, for example, index = c(\"unit.id\", \"time\").")
    }
    
    unique_label <- unique(paste(data[,index[1]],"_",data[,index[2]],sep=""))
    if (length(unique_label)!= dim(data)[1]) {
        stop("Some records may be duplicated or wrongly marked in the data set. Check the index.")
    }

    ## force
    if (force == "none") { # force = 0 "none": no additive fixed effects imposed
        force <- 0
    } else if (force == "unit") { # force = 1 "unit": unit fixed-effect (default)
        force <- 1
    } else if (force == "time") { # force = 2 "time": time fixed-effect
        force <- 2
    } else if (force == "two-way") { # force = 3 "two-way": two-way fixed-effect 
        force <- 3
    }
    if (!force %in% c(0, 1, 2, 3)) {
        stop("\"force\" option misspecified; choose from c(\"none\", \"unit\", \"time\", \"two-way\").")
    } 

    ## method
    if (!method %in% c("fe", "mc")) {
        stop("\"method\" option misspecified; choose from c(\"fe\", \"mc\").")
    }

    ## r
    if ( method == "fe" & r[1] < 0) {
        stop("\"r\" option misspecified. The number of factors must be non-negative.")
    }

    ## lambda
    if ( method == "mc" & !is.null(lambda)) {
        if (sum(lambda < 0) > 0) {
            stop("\"lambda\" option misspecified. It must be non-negative.")    
        }
    } 

    ## CV
    if (CV == TRUE) {
        if (method == "fe") {
            if (length(r) == 2 & r[1] > r[2]) {
                stop("\"r\" option misspecified.")
            }
        } else {
            if (nlambda <= 0) {
                stop("\"nlambda\" option misspecified.")
            }
        }  
    }

    if (length(r) == 1) {
        if (r>=5) {
            r.end <- r
        } else {
            r.end <- 5
        }
    } else {
        r.end <- r[2]; r <- r[1]
    }

    ## se
    if (is.logical(se) == FALSE & !se%in%c(0, 1)) {
        stop("se is not a logical flag.")
    } 

    ## normalize
    if (is.logical(normalize) == FALSE & !normalize%in%c(0, 1)) {
        stop("normalize is not a logical flag.")
    } 

    ## nboots
    if (se == TRUE & nboots <= 0) {
        stop("\"nboots\" option misspecified. Try, for example, nboots = 200.")
    }

    ## parallel & cores
    if (parallel == TRUE) {
        if (is.null(cores) == FALSE) {
            if (cores <= 0) {
                stop("\"cores\" option misspecified. Try, for example, cores = 2.")
            }
        }
    } 

    ## tol
    if (tol <= 0) {
        stop("\"tol\" option misspecified. Try using the default option.")
    }

    ## seed
    if (is.null(seed) == FALSE) {
        if (is.numeric(seed) == FALSE) {
            stop("seed should be a number.")
        }
    }

    ## remove missing values
    if (is.logical(na.rm) == FALSE & !na.rm%in%c(0, 1)) {
        stop("na.rm is not a logical flag.")
    } 

    if (na.rm == TRUE) {
    	data <- data[,c(index, Y, D, X)] ## some variables may not be used
        data <- na.omit(data)
    }

    ## placebo period
    if (!is.null(placebo.period)) {
        if (sum(placebo.period > 0) > 0) {
            stop("\"placebo.period\" should not be greater than 0.")
        } else {
            if (length(placebo.period) > 2) {
                stop("\"placebo.period\" option misspecified. ")
            }
        }
    }

    ##-------------------------------##
    ## Parsing raw data
    ##-------------------------------##  

    ##store variable names
    data.old <- data
    Yname <- Y
    Dname <- D
    Xname <- X

    ## normalize
    norm.para <- NULL
    if (normalize == TRUE) {
        sd.Y <- sd(as.matrix(data[,Yname]))
        data[,c(Yname, Xname)] <- data[,c(Yname, Xname)]/sd.Y
        norm.para <- sd.Y ## normalized parameter
    }
    
    id <- index[1]
    time <- index[2]
    TT <- length(unique(data[,time]))
    N <- length(unique(data[,id]))
    p <- length(Xname)
    id.series <- unique(sort(data[,id])) ## unit id
    time.uni <- unique(sort(data[,time])) ## period

    ## sort data
    data <- data[order(data[,id], data[,time]), ]

    ## max.missing
    if (is.null(max.missing)) {
        max.missing <- TT
    }
    
    ## check missingness
    if (sum(is.na(data[, Yname])) > 0) {
        stop(paste("Missing values in variable \"", Yname,"\".", sep = ""))
    }
    if (sum(is.na(data[, Dname])) > 0) {
        stop(paste("Missing values in variable \"", Dname,"\".", sep = ""))
    }

    if (!(1%in%data[, Dname] & 0%in%data[,Dname] & length(unique(data[,Dname])) == 2)) {
        stop(paste("Error values in variable \"", Dname,"\".", sep = ""))
    }

    if (p > 0) {
        for (i in 1:p) {
            if (sum(is.na(data[, Xname[i]])) > 0) {
                stop(paste("Missing values in variable \"", Xname[i],"\".", sep = ""))
            }
        }
    }

    if (sum(is.na(data[, id])) > 0) {
        stop(paste("Missing values in variable \"", id,"\".", sep = ""))
    }
    if (sum(is.na(data[, time])) > 0) {
        stop(paste("Missing values in variable \"", time,"\".", sep = ""))
    } 

    ## check balanced panel and fill unbalanced panel
    if (var(table(data[,id])) + var(table(data[, time])) > 0 | TT == N) {
        
        data[,time]<-as.numeric(as.factor(data[,time]))
        ob <- "time_ob_ls"
        
        while(ob%in%colnames(data)){
            ob <- paste(ob,ob,sep="")
        }

        data[,ob]<-data[,time]
        for (i in 1:N) {
            data[data[,id] == id.series[i], ob] <- data[data[,id] == id.series[i],time] + (i - 1) * TT  
        }

        variable <- c(Yname, Dname, Xname)

        data_I <- matrix(0, N * TT, 1)
        data_I[c(data[,ob]), 1] <- 1
        data_ub <- as.matrix(data[, variable])
        data <- data_ub_adj(data_I, data_ub)
        colnames(data) <- variable
    }

    ## index matrix that indicates if data is observed 
    I <- matrix(1, TT, N)
    Y.ind <- matrix(data[, Yname], TT, N)
    I[is.nan(Y.ind)] <- 0

    if (0%in%I) {
    	data[is.nan(data)] <- 0
    }
    
    ##treatment indicator: incorporates reversal treatments
    DD <- D <- matrix(data[, Dname], TT, N)

    ##outcome variable
    Y <- matrix(data[, Yname], TT, N)

    ## placebo period 
    T.on <- t.on <- NULL
    if (placeboTest == TRUE) {
        T.on <- matrix(NA, TT, N)
        for (i in 1:N) {
            if (sum(D[,i]) > 0) {
                T.on[,i] <- get_term(D[,i], I[,i], type = "on")
            }
        }
        D[which(T.on >= min(placebo.period) & T.on <= max(placebo.period) & I == 1)] <- 1 ## for placebo test, some pre-treatment observations will not be used.
        ## T.on.b <- is.na(T.on)
        ## Tr.pos <- which(apply(T.on.b, 2, sum) < TT)
        ## T.on.tr <- as.matrix(T.on[,Tr.pos])
        ## tr.rm <- which(apply(T.on.tr, 2, min, na.rm = TRUE) >= min(placebo.period))
        ## rm.id <- c(rm.id, Tr.pos[tr.rm])
        ## t.on <- c(T.on[,-Tr.pos[tr.rm]])
    }

    
    II <- I
    II[which(D==1)] <- 0 ## regard treated values as missing, II for fastplm, initial value for beta, alpha, xi

    D <- DD ## recover D

    I.use <- apply(II, 1, sum) ## check if in some periods all units are missing
    if (0%in%I.use) {
        for (i in 1:TT) {
            if (I.use[i] == 0) {
                cat("There are not any observations at ",time.uni[i],", drop that period.\n")
            }
        }
        TT <- TT - sum(I.use == 0)
        time.uni <- time.uni[-which(I.use == 0)]
        
        I <- I[-which(I.use == 0),] ## remove that period
        D <- D[-which(I.use == 0),] ## remove that period
        Y <- Y[-which(I.use == 0),] ## remove that period
        II <- II[-which(I.use == 0),] ## remove that period

        ## Y[which(I==0)] <- 0
        data <- data[-which(rep(I.use, N) == 0),] ## remove that period
    }

    T0 <- apply(II, 2, sum)
    T0.min <- min(T0)

    if (sum(T0[which(apply(D, 2, sum) > 0)] >= min.T0) == 0) {
        stop ("All treated units have been removed.\n")
    }   
    ## T0.min : minimum T0,  min.T0: manually set
    ## rm.tr.id: relative location of treated units (within all treated units) 
    ## that will be removed 
    if (T0.min < min.T0) {
        cat("Some treated units has too few pre-treatment periods. \nThey will be automatically removed.\n")
    }

    rm.id <- sort(unique(c(which((TT - apply(I, 2, sum)) > max.missing), which(T0 < min.T0))))
    ## rm.id <- which(T0 < min.T0) ## removed id
    ## rem.id <- which(T0 >= min.T0) ## remained id
    
    rem.id <- setdiff(1:N, rm.id)

    if (length(rm.id) == N) {
        stop("All treated units have been removed.\n")
    }

    ## time-varying covariates
    X <- array(0, dim = c(TT, N, p))
    xp <- rep(0, p) ## label invariant x
    x.pos <- 0

    if (p > 0) {
        x.pos <- 1:p
        for (i in 1:p) {
            X[,,i] <- matrix(data[, Xname[i]], TT, N)
            if (force %in% c(1,3)) {
                if (!0%in%I) {
                    tot.var.unit <- sum(apply(X[, , i], 2, var))
                } else {
                    Xi <- X[,,i]
                    Xi[which(I == 0)] <- NA
                    tot.var.unit <- sum(apply(Xi, 2, var, na.rm = TRUE))
                }
                if(!is.na(tot.var.unit)) {
                    if (tot.var.unit == 0) {
                        ## time invariant covar can be removed
                        xp[i] <- 1
                        cat(paste("Variable \"", Xname[i],"\" is time-invariant.\n", sep = ""))   
                    }
                }
            }
            if (force %in% c(2, 3)) {
                if (!0%in%I) {
                    tot.var.time <- sum(apply(X[, , i], 1, var))
                } else {
                    Xi <- X[,,i]
                    Xi[which(I == 0)] <- NA
                    tot.var.time <- sum(apply(Xi, 1, var, na.rm = TRUE))
                } 
                if (!is.na(tot.var.time)) {
                    if (tot.var.time == 0) {
                        ## can be removed in inter_fe
                        xp[i] <- 1
                        cat(paste("Variable \"", Xname[i],"\" has no cross-sectional variation.\n", sep = ""))
                    }
                }
            } 
        } 
    }

    if (sum(xp) > 0) {
        if (sum(xp) == p) {
            X <- array(0, dim = c(TT, N, 0))
            p <- 0
        } else {
            x.pos <- which(xp == 0)
            Xsub <- array(0, dim = c(TT, N, length(x.pos)))
            for (i in 1:length(x.pos)) {
                Xsub[,,i] <- X[,,x.pos[i]] 
            }
            X <- Xsub
            p <- length(x.pos)
        }
    }

    if (length(rm.id) > 0) {

        X.old <- X
        if (p > 0) {
            X <- array(0,dim = c(TT, (N - length(rm.id)), p))
            for (i in 1:p) {
                subX <- X.old[, , i]
                X[, , i] <- as.matrix(subX[, -rm.id])
            }
        } else {
            X <- array(0,dim = c(TT, (N - length(rm.id)), 0))
        }

        Y <- as.matrix(Y[,-rm.id])
        D <- as.matrix(D[,-rm.id])
        I <- as.matrix(I[,-rm.id]) ## after removing
        ## N <- N - length(rm.id)
    }    

    if (is.null(dim(X)[3]) == TRUE) {
        p <- 0
    } else {
        p <- dim(X)[3]
    }

    ## D.fake : check reversals
    D.fake <- apply(D, 2, function(vec){cumsum(vec)})
    D.fake <- ifelse(D.fake > 0, 1, 0)
    D.fake[which(I==0)] <- 0

    Nrev <- sum(apply(D.fake == D, 2, sum) != TT)

    ## treated units
    ## tr <- which(apply(D, 2, sum) > 0) ## units that have been treated 
    ## Nco <- N - length(tr)
    ## Ntr <- length(tr) - Nrev
    hasRevs <- ifelse(Nrev > 0, 1, 0)

    ## if (AR1 == TRUE) {
    ##     Y.first <- Y[1,]
    ##     Y.lag <- Y[1:(T-1),]
    ##     Y <- Y[2:T,]
    ##     D <- D[2:T,]
    ##     if (p == 0) {
    ##         X <- array(NA, dim=c((T-1),N,1))
    ##         X[,,1] <- Y.lag
    ##     } else {
    ##         X.first <- X[1,,]
    ##         X.sav <- X[2:T,,]
    ##         X <- array(NA,dim=c((T-1),N,(p+1)))
    ##         X[,,1] <- Y.lag
    ##         X[,,2:(p+1)] <- X.sav
    ##     }
    ##     T <- T-1
    ## } 

    ##-------------------------------##
    ## Register clusters
    ##-------------------------------##
    
    if ((se == TRUE | fitTest == TRUE) & parallel==TRUE) {
   
        if (is.null(cores) == TRUE) {
            cores <- detectCores()
        }
        para.clusters <- makeCluster(cores)
        registerDoParallel(para.clusters)
        cat("Parallel computing ...\n")
    }
    
    ##-------------------------------##
    ## run main program
    ##-------------------------------##

    if (se == FALSE & fitTest == FALSE) {
        if (method == "fe") {
            out <- fect.fe(Y = Y, X = X, D = D, I = I, 
                           r = r, r.end = r.end, force = force,
                           CV = CV, k = k, hasRevs = hasRevs, tol = tol, 
                           norm.para = norm.para, 
                           placebo.period = placebo.period)
        } else {
            out <- fect.mc(Y = Y, X = X, D = D, I = I, 
                           lambda = lambda, nlambda = nlambda, force = force, 
                           CV = CV, k = k, hasRevs = hasRevs, tol = tol, 
                           norm.para = norm.para,
                           placebo.period = placebo.period)
        } 
    } else  {
        if (is.null(seed) == FALSE) {
            set.seed(seed)
        }
        if (fitTest == TRUE) {
            if (fitBoot == "wild") {
                out <- fect.test(Y = Y, X = X, D = D, I = I, 
                                 r = r, r.end = r.end, lambda = lambda,
                                 nlambda = nlambda,
                                 force = force, method = method,
                                 CV = CV, k = k, hasRevs = hasRevs, tol = tol,
                                 nboots = nboots, 
                                 parallel = parallel, cores = cores,           
                                 norm.para = norm.para, 
                                 pre.period = placebo.period)
            } else {
                out <- fect.test2(Y = Y, X = X, D = D, I = I, 
                                  r = r, r.end = r.end, lambda = lambda,
                                  nlambda = nlambda,
                                  force = force, method = method,
                                  CV = CV, k = k, hasRevs = hasRevs, tol = tol,
                                  nboots = nboots, 
                                  parallel = parallel, cores = cores,           
                                  norm.para = norm.para, 
                                  pre.period = placebo.period)

            }

        } else {
            out <- fect.boot(Y = Y, X = X, D = D, I = I,
                             r = r, r.end = r.end, lambda = lambda,
                             nlambda = nlambda,
                             force = force, method = method,
                             CV = CV, k = k, hasRevs = hasRevs, tol = tol,
                             nboots = nboots, 
                             parallel = parallel, cores = cores,           
                             norm.para = norm.para, 
                             placebo.period = placebo.period, 
                             placebo.start = placebo.start, 
                             placeboTest = placeboTest)
        }

    } 

    if ((se == TRUE | fitTest == TRUE) & parallel == TRUE) {
        stopCluster(para.clusters)
        ##closeAllConnections()
    }

    if (fitTest == TRUE) {
        return(out)
    }

    if ( (out$validX == 0) & (p!=0) ) {
        warning("Multi-colinearity among covariates. Try removing some of them.\r")
    }    
    
    ##-------------------------------##
    ## storage
    ##-------------------------------## 
    
    iname.old <- iname <- unique(sort(data.old[,id]))
    ## tname.old <- tname <- unique(sort(data.old[,time]))
    if (!0%in%I.use) {
        tname.old <- tname <- unique(sort(data.old[,time]))
    } else {
        tname.old <- tname <- unique(sort(data.old[,time]))[which(I.use != 0)]
    }

    if (length(rm.id)>0) {
        remove.id <- iname[rm.id]
        iname <- iname[-rm.id]
    }

    N.rem <- dim(D)[2]
    unit.type <- rep(NA, N.rem) ## 1 for control; 2 for treated; 3 for reversal;
    for (i in 1:N.rem) {
        di <- D[, i]
        ii <- I[, i]
        if (length(unique(di[which(ii==1)])) == 1) { ## treated or control
            if (0 %in% unique(di[which(ii==1)])) {
                unit.type[i] <- 1 ## control
            } else {
                unit.type[i] <- 2 ## treated
            }
        } else {
            unit.type[i] <- 3 ## reversal
        }
    }
    
    # 1 treated 2 control 3 missing 4 removed    
    obs.missing <- matrix(0, TT, N) ## not under treatment
    obs.missing[, rem.id] <- D + as.matrix(abs(I - 1)) * 3 ## under treatment
    obs.missing[which(obs.missing==0)] <- 2
    obs.missing[, rm.id] <- 4 ## removed

    colnames(obs.missing) <- unique(sort(data.old[,id]))
    
    rownames(obs.missing) <- tname
    
    if (p > 0) {
        Xname.tmp <- Xname[x.pos]
        rownames(out$beta) <- Xname.tmp
        if (se == TRUE) {
            rownames(out$est.beta) <- Xname.tmp
        }
    }  
    colnames(out$eff) <- iname
    rownames(out$eff) <- tname
   
    output <- c(list(Y.dat = Y,
                     D.dat = D,
                     I.dat = I,
                     Y = Yname,
                     D = Dname,
                     X = Xname,
                     index = index,
                     id = iname,
                     time = tname,
                     unit.type = unit.type,
                     obs.missing = obs.missing), 
                     out)
                
    if (1 %in% rm.id) {
        output <- c(output,list(remove.id = remove.id))
        cat("list of removed units:",remove.id)
        cat("\n\n")
    }
    output <- c(output, list(call = match.call()))
    class(output) <- "fect"
    return(output)
    
} ## Program fect ends 


###################################################################
## IFE Model Function
###################################################################
fect.fe <- function(Y, # Outcome variable, (T*N) matrix
                    X, # Explanatory variables:  (T*N*p) array
                    D, #  Indicator for treated unit (tr==1) 
                    I,
                    r = 0, # initial number of factors considered if CV==1
                    r.end,
                    force,
                    CV = 1, # cross-validation
                    k = 5, # CV time
                    hasRevs = 1,
                    tol, # tolerance level
                    placebo.period = NULL,
                    norm.para = NULL,
                    time.on.seq = NULL,
                    time.off.seq = NULL) {  
    
    ##-------------------------------##
    ## Parsing data
    ##-------------------------------##  
    placebo.pos <- t.on <- T.on <- na.pos <- NULL


    ## unit id and time
    TT <- dim(Y)[1]
    N <- dim(Y)[2]
    if (is.null(X) == FALSE) {p <- dim(X)[3]} else {p <- 0}

    ## replicate data
    YY <- Y
    II <- I

    ## placebo period
    #if (!is.null(placebo.period) || CV == 1) {
        T.on <- matrix(NA, TT, N)
        for (i in 1:N) {
            T.on[, i] <-  get_term(D[,i], I[,i], type = "on")
        }
        #T.on[which(I==0)] <- NA
        #t.on <- c(T.on)
        if (!is.null(placebo.period)) {
            if (length(placebo.period) == 1) {
                ## YY[which(relaP%in%placebo.period)] <- 0
                placebo.pos <- which(T.on%in%placebo.period)
                II[placebo.pos] <- 0
            } else {
                placebo.pos <- which(T.on >= placebo.period[1] & T.on <= placebo.period[2])
                ## YY[placebo.pos] <- 0
                II[placebo.pos] <- 0
            }
        }
        T.on[which(I==0)] <- NA
        t.on <- c(T.on)
    #}

    ## treat post-treatment period treated units as missing
    ## YY[which(D==1)] <- 0
    II[which(D==1)] <- 0
    YY[which(II == 0)] <- 0 ## reset to 0
    T0.min <- min(apply(II, 2, sum))

    if (CV == 1) {
        obs.con <- (sum(II) - r.end * (N + TT) + r.end^2 - p) <= 0
        if (obs.con) {
            while((sum(II) - r.end * (N + TT) + r.end^2 - p)<=0) {
                r.end <- r.end - 1
            }
        }
        if (r.end >= T0.min) {
            cat("Facotr number should not be greater than ", T0.min-1, "\n", sep = "")
            r.end <- T0.min-1
        } else {
            if (obs.con) {
                cat("Facotr number should not be greater than ", r.end, "\n", sep = "")
            }
        }
    }

    ## initial fit using fastplm
    data.ini <- matrix(NA, (TT*N), (2 + 1 + p))
    data.ini[, 2] <- rep(1:N, each = TT)         ## unit fe
    data.ini[, 3] <- rep(1:TT, N)                ## time fe
    data.ini[, 1] <- c(Y)                       ## outcome
    if (p > 0) {                                ## covar
        for (i in 1:p) {
            data.ini[, (3 + i)] <- c(X[, , i])
        }
    }

    ## observed Y0 indicator:
    oci <- which(c(II) == 1)

    initialOut <- initialFit(data = data.ini, force = force, oci = oci)
    Y0 <- initialOut$Y0
    beta0 <- initialOut$beta0

    if (sum(is.na(beta0)) > 0) {
        beta0[which(is.na(beta0))] <- 0
    }

    
    ##-------------------------------##
    ## Main Algorithm
    ##-------------------------------##
    validX <- 1 ## no multi-colinearity
    
    if (CV == FALSE) { ## case: CV==0        
        est.best <- inter_fe_ub(YY, Y0, X, II, beta0, r, force = force, tol)  
        r.cv <- r.max <- r
        
    }  else if (CV == TRUE) { 
        
        ##-------------------------------##
        ## Cross-validation of r
        ##-------------------------------##
        
        ## starting r    
        ## if ((r > (T0.min-1) & force%in%c(0,2)) | (r > (T0.min-2) & force%in%c(1,3))) {
        ##     cat("Warning: r is too big compared with T0; reset to 0.\n")
        ##     r <- 0
        ## }
        
        ## initial values
        cat("Cross-validating ...","\r")
        
        ## store all MSPE
        ## if (force%in%c(0, 2)) {
        ##     r.max <- max(min((T0.min-1), r.end), 0)
        ## } else {
        ##     r.max <- max(min((T0.min-2), r.end), 0)
        ## }
        r.max <- min(TT, r.end)

        if (r.max == 0) {
            r.cv <- 0
            cat("Cross validation cannot be performed since available pre-treatment records of treated units are too few. So set r.cv = 0.\n ")
            est.best <- inter_fe_ub(YY, Y0, X, II, beta0, 0, force = force, tol)

        } else {

            ## tot.id <- which(c(II)==1) ## observed control data
            cv.count <- ceiling((sum(II)*sum(II))/sum(I))

            CV.out <- matrix(NA, (r.max - r + 1), 5)
            colnames(CV.out) <- c("r", "sigma2", "IC", "MSPE", "MSPTATT")
            CV.out[,"r"] <- c(r:r.max)
            CV.out[,"MSPE"] <- 1e20
            
            ociCV <- matrix(NA, cv.count, k) ## store indicator
            rmCV <- matrix(NA, (length(oci) - cv.count), k) ## removed indicator
            Y0CV <- array(NA, dim = c(TT, N, k)) ## store initial Y0
            if (p > 0) {
               beta0CV <- array(NA, dim = c(p, 1, k)) 
            } else {
                beta0CV <- array(0, dim = c(1, 0, k)) ## store initial beta0
            }
            
            for (i in 1:k) {
                cv.n <- 0
                repeat{
                    cv.n <- cv.n + 1
                    cv.id <- cv.sample(II, as.integer(sum(II) - cv.count))
                    ## cv.id <- sample(oci, as.integer(sum(II) - cv.count), replace = FALSE)
                    II.cv <- II
                    II.cv[cv.id] <- 0
                    con1 <- sum(apply(II.cv, 1, sum) > 0) == TT
                    con2 <- sum(apply(II.cv, 2, sum) > 0) == N
                    if (con1 & con2) {
                        break
                    }
                    if (cv.n > 100) {
                        stop("Some units have too few pre-treatment observations. Try to remove them.")
                    }
                }
                rmCV[,i] <- cv.id
                ocicv <- setdiff(oci, cv.id)
                ociCV[,i] <- ocicv

                initialOutCv <- initialFit(data = data.ini, force = force, oci = ocicv)
                Y0CV[,,i] <- initialOutCv$Y0
                
                if (p > 0) {
                    beta0cv <- initialOutCv$beta0
                    if (sum(is.na(beta0cv)) > 0) {
                        beta0cv[which(is.na(beta0cv))] <- 0
                    }
                    beta0CV[,,i] <- beta0cv
                }
            }

            cv.pos <- which(t.on<=0)
            t.on.cv <- t.on[cv.pos]
            count.on.cv <- as.numeric(table(t.on.cv))
        
            for (i in 1:dim(CV.out)[1]) { ## cross-validation loop starts 
  
                ## inter FE based on control, before & after 
                r <- CV.out[i, "r"]  
                ## k <- 5
                SSE <- 0
                for (ii in 1:k) {
                    II.cv <- II
                    II.cv[rmCV[,ii]] <- 0
                    YY.cv <- YY
                    YY.cv[rmCV[,ii]] <- 0
                    est.cv.fit <- inter_fe_ub(YY.cv, as.matrix(Y0CV[,,ii]), X, II.cv, as.matrix(beta0CV[,,ii]), r, force, tol)$fit
                    SSE <- SSE + sum((YY[rmCV[,ii]]-est.cv.fit[rmCV[,ii]])^2)
                }
                MSPE <- SSE/(k*(sum(II) - cv.count))

                est.cv <- inter_fe_ub(YY, Y0, X, II, beta0, r, force, tol) ## overall
                sigma2 <- est.cv$sigma2 
                IC <- est.cv$IC

                eff.v.cv <- c(Y - est.cv$fit)[cv.pos]
                meff <- as.numeric(tapply(eff.v.cv, t.on.cv, mean))
                MSPTATT <- sum(meff^2*count.on.cv)/sum(count.on.cv)
                

                if(!is.null(norm.para)) {
                    MSPE <- MSPE*(norm.para[1]^2)
                    sigma2 <- sigma2*(norm.para[1]^2)
                    IC <- est.cv$IC - log(est.cv$sigma2) + log(sigma2)
                }

                if ((min(CV.out[,"MSPE"]) - MSPE) > tol*min(CV.out[,"MSPE"])) {
                    ## at least 5% improvement for MPSE
                    est.best <- est.cv  
                    r.cv <- r
                } else {
                    if (r == r.cv + 1) cat("*")
                }
                CV.out[i, 2:5] <- c(sigma2, IC, MSPE, MSPTATT)

                cat("\n r = ",r, "; sigma2 = ",
                    sprintf("%.5f",sigma2), "; IC = ",
                    sprintf("%.5f",IC), "; MSPE = ",
                    sprintf("%.5f",MSPE), "; MSPTATT = ",
                    sprintf("%.5f",MSPTATT), sep="")
            
            } ## end of while: search for r_star over
        
            if (r > (TT-1)) {cat(" (r hits maximum)")}
            cat("\n\n r* = ",r.cv, sep="")
            cat("\n\n") 
        
            MSPE.best <- min(CV.out[,"MSPE"])
        }
        
    } ## End of Cross-Validation

    validX <- est.best$validX
    validF <- ifelse(r.cv > 0, 1, 0)
    if (p>0) {
        na.pos <- is.nan(est.best$beta)
        beta <- est.best$beta
        if( sum(na.pos) > 0 ) {
            beta[na.pos] <- NA
        }
    } else {
        beta <- NA
    }
    
    ##-------------------------------##
    ## ATT and Counterfactuals 
    ##-------------------------------##
    
    ## variance of the error term
    if (is.null(norm.para)) {
        sigma2 <- est.best$sigma2   
        IC <- est.best$IC
    } else {
        sigma2 <- est.best$sigma2 * (norm.para[1]^2)
        IC <- est.best$IC - log(est.best$sigma2) + log(sigma2)       
    }
 
    ## ## take out the effect of X
    mu <- est.best$mu
    res <- est.best$residuals
    
    if (force%in%c(1,3)) {
        alpha <- est.best$alpha ## a (N*1) matrix
    }
    if (force%in%c(2,3)) {
        xi <- est.best$xi ## a (TT*1) matrix
    }
   
    ##-------------------------------##
    ## Summarize
    ##-------------------------------## 
    Y.ct <- est.best$fit
    eff <- Y - Y.ct  
    att.avg <- sum(eff * D)/(sum(D))

    ## final adjust unbalanced output
    if (0%in%I) {
        eff[which(I == 0)] <- NA
        Y.ct[which(I == 0)] <- NA
        res[which(II == 0)] <- NA
    }
    
    ## placebo effect
    if (!is.null(placebo.period)) {
        ## D.placebo <- matrix(0, TT, N)
        ## D.placebo[placebo.pos] <- 1
        ## att.placebo <- sum(eff * D.placebo)/(sum(D.placebo))
        eff.placebo <- c(eff[placebo.pos])
        att.placebo <- mean(eff.placebo, na.rm = TRUE)
    }
    
    
    ## final adjustment
    if (!is.null(norm.para)) {
        mu <- mu * norm.para[1]
        if (r.cv > 0) {
            est.best$lambda <- est.best$lambda * norm.para[1]
        }
        if (force%in%c(1, 3)) {
            alpha <- alpha * norm.para[1]
        }
        if (force%in%c(2,3)) {
            xi <- xi * norm.para[1]
        }
        res <- res * norm.para[1] 
        Y.ct <- Y.ct * norm.para[1]
        eff <- eff * norm.para[1]
        att.avg <- att.avg * norm.para[1]
    }

    eff.v <- c(eff) ## a vector
    
    ## switch on tt: always has
    ## term
    ## t.on <- c(apply(D, 2, get_term, type = "on")) ## vector
    
    #if (CV == 0 || is.null(placebo.period)) {
    #    t.on <- NULL
    #    for (i in 1:N) {
    #        t.on <- c(t.on, get_term(D[,i], I[,i], type = "on"))
    #    }
    
    #    T.on <- matrix(t.on, TT, N)
    #}

    rm.pos1 <- which(is.na(eff.v))
    rm.pos2 <- which(is.na(t.on))
    eff.v.use1 <- eff.v
    t.on.use <- t.on
    n.on.use <- rep(1:N, each = TT)

    if (NA %in% eff.v | NA %in% t.on) {
        eff.v.use1 <- eff.v[-c(rm.pos1, rm.pos2)]
        t.on.use <- t.on[-c(rm.pos1, rm.pos2)]
        n.on.use <- n.on.use[-c(rm.pos1, rm.pos2)]
    }

    pre.pos <- which(t.on.use <= 0)
    eff.pre <- cbind(eff.v.use1[pre.pos], t.on.use[pre.pos], n.on.use[pre.pos])
    colnames(eff.pre) <- c("eff", "period", "unit")

    time.on <- sort(unique(t.on.use))
    att.on <- as.numeric(tapply(eff.v.use1, t.on.use, mean)) ## NA already removed
    count.on <- as.numeric(table(t.on.use))

    if (!is.null(time.on.seq)) {
        count.on.med <- att.on.med <- rep(NA, length(time.on.seq))
        att.on.med[which(time.on.seq %in% time.on)] <- att.on
        count.on.med[which(time.on.seq %in% time.on)] <- count.on
        att.on <- att.on.med
        count.on <- count.on.med
        time.on <- time.on.seq
    }

    if (hasRevs == 1) { ## if has reversals, calculate switch-off tt   
        ## t.off <- c(apply(D, 2, get_term, type = "off")) ## vector
        t.off <- NULL
        for (i in 1:N) {
            t.off <- c(t.off, get_term(D[,i], I[,i], type = "off"))
        }
        rm.pos3 <- which(is.na(t.off))
        eff.v.use2 <- eff.v
        t.off.use <- t.off

        if (NA %in% eff.v | NA %in% t.off) {
            eff.v.use2 <- eff.v[-c(rm.pos1, rm.pos3)]
            t.off.use <- t.off[-c(rm.pos1, rm.pos3)]
        }

        time.off <- sort(unique(t.off.use))
        att.off <- as.numeric(tapply(eff.v.use2, t.off.use, mean)) ## NA already removed
        count.off <- as.numeric(table(t.off.use))

        if (!is.null(time.off.seq)) {
            count.off.med <- att.off.med <- rep(NA, length(time.off.seq))
            att.off.med[which(time.off.seq %in% time.off)] <- att.off
            count.off.med[which(time.off.seq %in% time.off)] <- count.off
            att.off <- att.off.med
            count.off <- count.off.med
            time.off <- time.off.seq
        }
    }

  
    ##-------------------------------##
    ## Storage 
    ##-------------------------------##  

    ##control group residuals
    out<-list(
        ## main results
        D = D,
        I = I,
        Y = Y,
        T.on = T.on,
        Y.ct = Y.ct,
        eff = eff,
        att.avg = att.avg,
        ## supporting
        force = force,
        T = TT,
        N = N,
        p = p,
        r.cv = r.cv, 
        IC = IC,
        beta = beta,
        est = est.best,
        mu = mu,
        niter = est.best$niter,
        validX = validX,
        validF = validF,
        time.on = time.on,
        att.on = att.on,
        count.on = count.on,
        eff.pre = eff.pre
    )

    out <- c(out, list(sigma2 = sigma2, res = res))

    if (hasRevs == 1) {
        out <- c(out, list(time.off = time.off, 
                           att.off = att.off,
                           count.off = count.off))
    }

    if (CV == 1 & r.max != 0) {
        out<-c(out, list(MSPE = MSPE.best,
                         CV.out = CV.out,
                         rmCV = rmCV))
    }
    if (r.cv > 0) {
        out<-c(out,list(factor = as.matrix(est.best$factor),
                        lambda = as.matrix(est.best$lambda)
                   )) 
    } 
    if (force == 1) {
        out<-c(out, list(alpha = alpha))
    } else if (force == 2) {
        out<-c(out,list(xi = xi))
    } else if (force == 3) {
        out<-c(out,list(alpha = alpha, xi = xi))
    }

    if (!is.null(placebo.period)) {
        out <- c(out, list(att.placebo = att.placebo))
    }

    return(out)
} ## fe functions ends


###################################################################
## Matrix Completion Function
###################################################################
fect.mc <- function(Y, # Outcome variable, (T*N) matrix
                    X, # Explanatory variables:  (T*N*p) array
                    D, #  Indicator for treated unit (tr==1) 
                    I,
                    lambda = NULL,
                    nlambda = 10,
                    force,
                    CV = 1,
                    k = 5,
                    hasF = 1,
                    hasRevs = 1, 
                    tol, # tolerance level
                    norm.para = NULL,
                    placebo.period = NULL,
                    time.on.seq = NULL,
                    time.off.seq = NULL) {  
    
    
    ##-------------------------------##
    ## Parsing data
    ##-------------------------------##  
    placebo.pos <- T.on <- t.on <- na.pos <- NULL
   
    ## unit id and time
    TT <- dim(Y)[1]
    N <- dim(Y)[2]
    if (is.null(X) == FALSE) {p <- dim(X)[3]} else {p <- 0}

    ## replicate data
    YY <- Y
    II <- I

    ## placebo period
    #if (!is.null(placebo.period) || CV == 1) {
        T.on <- matrix(NA, TT, N)
        for (i in 1:N) {
            T.on[, i] <-  get_term(D[,i], I[,i], type = "on")
        }
        #T.on[which(I==0)] <- NA
        #t.on <- c(T.on)
        if (!is.null(placebo.period)) {
            if (length(placebo.period) == 1) {
                ## YY[which(relaP%in%placebo.period)] <- 0
                placebo.pos <- which(T.on%in%placebo.period)
                II[placebo.pos] <- 0
            } else {
                placebo.pos <- which(T.on >= placebo.period[1] & T.on <= placebo.period[2])
                ## YY[placebo.pos] <- 0
                II[placebo.pos] <- 0
            }
        }
        T.on[which(I==0)] <- NA
        t.on <- c(T.on)
    #}


    ## treat post-treatment period treated units as missing
    ## YY[which(D==1)] <- 0
    II[which(D==1)] <- 0
    YY[which(II == 0)] <- 0 ## reset to 0

    ## initial fit using fastplm
    data.ini <- matrix(NA, (TT*N), (2 + 1 + p))
    data.ini[, 2] <- rep(1:N, each = TT)         ## unit fe
    data.ini[, 3] <- rep(1:TT, N)                ## time fe
    data.ini[, 1] <- c(Y)                       ## outcome
    if (p > 0) {                                ## covar
        for (i in 1:p) {
            data.ini[, (3 + i)] <- c(X[, , i])
        }
    }

    ## observed Y0 indicator:
    oci <- which(c(II) == 1)

    initialOut <- initialFit(data = data.ini, force = force, oci = oci)
    Y0 <- initialOut$Y0
    beta0 <- initialOut$beta0
    
    ##-------------------------------##
    ## Main Algorithm
    ##-------------------------------##

    validX <- 1 ## no multi-colinearity
    
    if (CV == FALSE) { ## case: CV==0 or no factor  
        ## matrix completion
        est.best <- inter_fe_mc(YY, Y0, X, II, beta0, hasF, lambda[1], force, tol) 
        lambda.cv <- lambda[1]    
    } else { 
        
        ##-------------------------------##
        ## Cross-validation of lambda
        ##-------------------------------##
        
        ## initial values
        cat("Cross-validating ...","\r")

        ## tot.id <- which(c(II)==1) ## observed control data
        cv.count <- ceiling((sum(II)*sum(II))/sum(I))

        if (is.null(lambda) || length(lambda) == 1) {
            ## create the hyper-parameter sequence
            ## lambda.max <- log10(max(svd(Y)$d)*2/(N*TT-sum(II)))
            ## Y.l <- YY - Y0
            ## Y.l[which(II == 0)] <- 0

            lambda.max <- log10(max(svd(YY)$d))
            lambda <- rep(NA, nlambda)
            lambda.by <- 3/(nlambda - 2)
            for (i in 1:(nlambda - 1)) {
                lambda[i] <- 10^(lambda.max - (i - 1) * lambda.by)
            }
            lambda[nlambda] <- 0
        }
        
        ## store all MSPE
        CV.out <- matrix(NA, length(lambda), 4)
        colnames(CV.out) <- c("lambda", "sigma2", "MSPE", "MSPTATT")
        CV.out[,"lambda"] <- c(lambda)
        CV.out[,"MSPE"] <- 1e20

        ociCV <- matrix(NA, cv.count, k) ## store indicator
        rmCV <- matrix(NA, (length(oci) - cv.count), k) ## removed indicator
        Y0CV <- array(NA, dim = c(TT, N, k)) ## store initial Y0
        if (p > 0) {
            beta0CV <- array(NA, dim = c(p, 1, k)) 
        } else {
            beta0CV <- array(0, dim = c(1, 0, k)) ## store initial beta0
        }

        cv.pos <- which(t.on<=0)
        t.on.cv <- t.on[cv.pos]
        count.on.cv <- as.numeric(table(t.on.cv))

        for (i in 1:k) {
            cv.n <- 0
            repeat{
                cv.n <- cv.n + 1
                cv.id <- cv.sample(II, as.integer(sum(II) - cv.count))
                ## cv.id <- sample(oci, as.integer(sum(II) - cv.count), replace = FALSE)
                II.cv <- II
                II.cv[cv.id] <- 0
                con1 <- sum(apply(II.cv, 1, sum) > 0) == TT
                con2 <- sum(apply(II.cv, 2, sum) > 0) == N
                if (con1 & con2) {
                    break
                }
                if (cv.n > 100) {
                    stop("Some units have too few pre-treatment observations. Try to remove them.")
                }
            }
            rmCV[,i] <- cv.id
            ocicv <- setdiff(oci, cv.id)
            ociCV[,i] <- ocicv

            initialOutCv <- initialFit(data = data.ini, force = force, oci = ocicv)
            Y0CV[,,i] <- initialOutCv$Y0
                
            if (p > 0) {
                beta0cv <- initialOutCv$beta0
                if (sum(is.na(beta0cv)) > 0) {
                    beta0cv[which(is.na(beta0cv))] <- 0
                }
                beta0CV[,,i] <- beta0cv
            }
        }


        for (i in 1:length(lambda)) {    
            ## k <- 5
            SSE <- 0
            for (ii in 1:k) {
                II.cv <- II
                II.cv[rmCV[,ii]] <- 0
                YY.cv <- YY
                YY.cv[rmCV[,ii]] <- 0
                est.cv.fit <- inter_fe_mc(YY.cv, as.matrix(Y0CV[,,ii]), X, II.cv, as.matrix(beta0CV[,,ii]), 1, lambda[i], force, tol)$fit
                SSE <- SSE + sum((YY[rmCV[,ii]]-est.cv.fit[rmCV[,ii]])^2)
            }
            MSPE <- SSE/(k*(sum(II) - cv.count))

            est.cv <- inter_fe_mc(YY, Y0, X, II, beta0, 1, lambda[i], force, tol) ## overall
            sigma2 <- est.cv$sigma2

            eff.v.cv <- c(Y - est.cv$fit)[cv.pos]
            meff <- as.numeric(tapply(eff.v.cv, t.on.cv, mean))
            MSPTATT <- sum(meff^2*count.on.cv)/sum(count.on.cv) 

            if(!is.null(norm.para)){
                MSPE <- MSPE*(norm.para[1]^2)
                sigma2 <- sigma2*(norm.para[1]^2)
            }

            if ((min(CV.out[,"MSPE"]) - MSPE) > tol*min(CV.out[,"MSPE"])) {
                ## at least 5% improvement for MPSE
                est.best <- est.cv  
                lambda.cv <- lambda[i]
            } else {
                if (i > 1) {
                    if (lambda.cv == lambda[i-1]) cat("*")
                }
            }
            CV.out[i, "MSPE"] <- MSPE
            CV.out[i, "sigma2"] <- sigma2 

            cat("\n lambda = ",
            sprintf("%.5f",lambda[i]),"; sigma2 = ",
            sprintf("%.5f",sigma2),"; MSPE = ",
            sprintf("%.5f",MSPE), "; MSPTATT = ",
            sprintf("%.5f",MSPTATT), sep="")

        } 
        cat("\n\n lambda* = ",lambda.cv, sep="")
        cat("\n\n")
        MSPE.best <- min(CV.out[,"MSPE"])
    } ## End of Cross-Validation

    validX <- est.best$validX
    validF <- est.best$validF

    if (p>0) {
        na.pos <- is.nan(est.best$beta)
        beta <- est.best$beta
        if( sum(na.pos) > 0 ) {
            beta[na.pos] <- NA
        }
    } else {
        beta <- NA
    }
    
    ##-------------------------------##
    ## ATT and Counterfactuals 
    ##-------------------------------##
    
    ## variance of the error term
    if (is.null(norm.para)) {
        sigma2 <- est.best$sigma2   
        ## IC <- est.best$IC
    } else {
        sigma2 <- est.best$sigma2 * (norm.para[1]^2)
        ## IC <- est.best$IC - log(est.best$sigma2) + log(sigma2)       
    }
 
    ## ## take out the effect of X
    mu <- est.best$mu
    res <- est.best$residuals
    
    if (force%in%c(1,3)) {
        alpha <- est.best$alpha ## a (N*1) matrix
    }
    if (force%in%c(2,3)) {
        xi <- est.best$xi ## a (TT*1) matrix
    }
   
    ##-------------------------------##
    ## Summarize
    ##-------------------------------## 
    Y.ct <- est.best$fit
    eff <- Y - Y.ct  
    att.avg <- sum(eff * D)/(sum(D))

    ## final adjust unbalanced output
    if (0%in%I) {
        eff[which(I == 0)] <- NA
        Y.ct[which(I == 0)] <- NA
        res[which(II == 0)] <- NA
    }

    ## placebo effect
    if (!is.null(placebo.period)) {
        ## D.placebo <- matrix(0, TT, N)
        ## D.placebo[placebo.pos] <- 1
        ## att.placebo <- sum(eff * D.placebo)/(sum(D.placebo))
        eff.placebo <- c(eff[placebo.pos])
        att.placebo <- mean(eff.placebo, na.rm = TRUE)
    }
    
    ## adjust beta: invariant covar
    if (p > 0) {
        if( sum(na.pos) > 0 ) {
            beta[na.pos] <- NA
        }
    }

    ## final adjustment
    if (!is.null(norm.para)) {
        mu <- mu * norm.para[1]
        if (force%in%c(1, 3)) {
            alpha <- alpha * norm.para[1]
        }
        if (force%in%c(2,3)) {
            xi <- xi * norm.para[1]
        }
        res <- res * norm.para[1] 
        Y.ct <- Y.ct * norm.para[1]
        eff <- eff * norm.para[1]
        att.avg <- att.avg * norm.para[1]
    }

    eff.v <- c(eff) ## a vector
    
    ## switch on tt: always has
    ## term
    ## t.on <- c(apply(D, 2, get_term, type = "on")) ## vector
    #t.on <- NULL
    #for (i in 1:N) {
    #    t.on <- c(t.on, get_term(D[,i], I[,i], type = "on"))
    #}

    #T.on <- matrix(t.on, TT, N)
    
    rm.pos1 <- which(is.na(eff.v))
    rm.pos2 <- which(is.na(t.on))
    eff.v.use1 <- eff.v
    t.on.use <- t.on
    n.on.use <- rep(1:N, each = TT)

    if (NA %in% eff.v | NA %in% t.on) {
        eff.v.use1 <- eff.v[-c(rm.pos1, rm.pos2)]
        t.on.use <- t.on[-c(rm.pos1, rm.pos2)]
        n.on.use <- n.on.use[-c(rm.pos1, rm.pos2)]
    }

    pre.pos <- which(t.on.use <= 0)
    eff.pre <- cbind(eff.v.use1[pre.pos], t.on.use[pre.pos], n.on.use[pre.pos])
    colnames(eff.pre) <- c("eff", "period", "unit")
     

    time.on <- sort(unique(t.on.use))
    att.on <- as.numeric(tapply(eff.v.use1, t.on.use, mean)) ## NA already removed
    count.on <- as.numeric(table(t.on.use))

    if (!is.null(time.on.seq)) {
        count.on.med <- att.on.med <- rep(NA, length(time.on.seq))
        att.on.med[which(time.on.seq %in% time.on)] <- att.on
        count.on.med[which(time.on.seq %in% time.on)] <- count.on
        att.on <- att.on.med
        count.on <- count.on.med
        time.on <- time.on.seq
    }

    if (hasRevs == 1) { ## if has reversals, calculate switch-off tt   
        ## t.off <- c(apply(D, 2, get_term, type = "off")) ## vector

        t.off <- NULL
        for (i in 1:N) {
            t.off <- c(t.off, get_term(D[,i], I[,i], type = "off"))
        }
        
        rm.pos3 <- which(is.na(t.off))
        eff.v.use2 <- eff.v
        t.off.use <- t.off

        if (NA %in% eff.v | NA %in% t.off) {
            eff.v.use2 <- eff.v[-c(rm.pos1, rm.pos3)]
            t.off.use <- t.off[-c(rm.pos1, rm.pos3)]
        }

        time.off <- sort(unique(t.off.use))
        att.off <- as.numeric(tapply(eff.v.use2, t.off.use, mean)) ## NA already removed
        count.off <- as.numeric(table(t.off.use))

        if (!is.null(time.off.seq)) {
            count.off.med <- att.off.med <- rep(NA, length(time.off.seq))
            att.off.med[which(time.off.seq %in% time.off)] <- att.off
            count.off.med[which(time.off.seq %in% time.off)] <- count.off
            att.off <- att.off.med
            count.off <- count.off.med
            time.off <- time.off.seq
        }
    }
  
    ##-------------------------------##
    ## Storage 
    ##-------------------------------##  

    ##control group residuals
    out<-list(
        ## main results
        D = D,
        I = I,
        Y = Y,
        T.on = T.on,
        Y.ct = Y.ct,
        eff = eff,
        att.avg = att.avg,
        ## supporting
        force = force,
        T = TT,
        N = N,
        p = p,
        lambda.cv = lambda.cv, 
        beta = beta,
        est = est.best,
        mu = mu,
        validX = validX,
        validF = validF,
        niter = est.best$niter,
        time.on = time.on,
        att.on = att.on,
        count.on = count.on,
        eff.pre = eff.pre
    )

    out <- c(out, list(sigma2 = sigma2, res = res))

    if (hasRevs == 1) {
        out <- c(out, list(time.off = time.off, 
                           att.off = att.off,
                           count.off = count.off))
    }
    
    if (CV == 1) {
        out<-c(out, list(MSPE = MSPE.best,
                         CV.out = CV.out))
    }
    if (force == 1) {
        out<-c(out, list(alpha = alpha))
    } else if (force == 2) {
        out<-c(out,list(xi = xi))
    } else if (force == 3) {
        out<-c(out,list(alpha = alpha, xi = xi))
    }

    if (!is.null(placebo.period)) {
        out <- c(out, list(att.placebo = att.placebo))
    }

    return(out)
} ## mc functions ends

#####################################
## goodness of fit test: wild
#####################################
fect.test<-function(Y,
                    X,
                    D, ## input
                    I,
                    r=0, r.end,
                    lambda = NULL,
                    nlambda = 10,
                    method = "fe",
                    force,
                    CV, ## cross validation
                    k = 5,
                    hasRevs = 1,
                    nboots,
                    tol,
                    norm.para,
                    parallel = TRUE,
                    pre.period = NULL,
                    cores = NULL) {
    
    
    na.pos <- NULL
    TT <- dim(Y)[1]
    N <- dim(Y)[2]
    
    ## estimation
    if (method == "fe") {
        out <- fect.fe(Y = Y, X = X, D = D, I=I, r = r, r.end = r.end, 
                       force = force, CV = CV, k = k, hasRevs = 0, 
                       tol=tol, norm.para = norm.para, 
                       placebo.period = NULL)
    } else {
        out <- fect.mc(Y = Y, X = X, D = D, I = I, 
                       lambda = lambda, nlambda = nlambda, 
                       force = force, CV = CV, k = k, hasRevs = 0, 
                       tol=tol, norm.para = norm.para,
                       placebo.period = NULL)
    }

    ## output
    eff <- out$eff
    eff[which(is.na(eff))] <- 0

    ## relative treatment period
    T.on <- out$T.on

    ## fitted values Y0
    Y.f <- out$est$fit

    if (is.null(pre.period)) {
        pre.period <- c(min(c(T.on), na.rm = TRUE), 0)
    }

    pre.pos <- which(T.on <= pre.period[2] & T.on >= pre.period[1] & I == 1)

    ## demean pre-treatment tr eff under H0 for wild bootstrap
    #eff[pre.pos] <- eff[pre.pos] - mean(eff[pre.pos])

    ## observed F
    eff.pre <- as.data.frame(out$eff.pre)
    eff.pre <- eff.pre[which(eff.pre[,"period"] >= pre.period[1] & eff.pre[,"period"] <= pre.period[2]),]

    lm.fit <- lm(eff ~ factor(period), data = eff.pre)
    #res <- lm.fit$residuals
    #f <- ((sum(eff.pre[,"eff"]^2) - sum(res^2))/length(unique(eff.pre[,"period"])))/(sum(res^2)/(dim(eff.pre)[1] - length(unique(eff.pre[,"period"]))))
    f <- summary(lm.fit)$f[1]


    ## bootstrapped F under H0
    f.boot <- rep(NA, nboots)

    cat("\rBootstrapping ...\n")
 
    if (method == "fe") {
        one.nonpara <- function() {
                
            ## res.p <- matrix(sample(c(-1, 1), N*TT, replace = TRUE), TT, N)
            res.p <- matrix(rep(sample(c(-1, 1), N, replace = TRUE), each = TT), TT, N)
            Y.boot <- Y.f + res.p * eff
            Y.boot[which(I == 0)] <- 0
            boot <- try(fect.fe(Y = Y.boot, X = X, D = D,
                            I = I, hasRevs = 0, 
                            force = force, r = out$r.cv, CV = 0,
                            tol = tol, time.on.seq = out$time.on, 
                            time.off.seq = out$time.off,
                            norm.para = norm.para,
                            placebo.period = NULL))
            
            if ('try-error' %in% class(boot)) {
                cat("NA")
                return(NA)
            } else {
                cat(out$niter)
                cat("\n")
                data <- as.data.frame(boot$eff.pre)
                #colnames(data) <- c("period", "eff")
                data <- data[which(data[,"period"] <= pre.period[2] & data[,"period"] >= pre.period[1]),]
                lm.fit.boot <- lm(eff~factor(period), data = data)
                #f.boot <- ((sum(data[,"eff"]^2) - sum((lm.fit.boot$residuals)^2))/length(unique(data[,"period"])))/(sum((lm.fit.boot$residuals)^2)/(dim(data[1]-unique(data[,"period"]))))
                f.boot <- summary(lm.fit.boot)$f[1]
                return(f.boot)  
            }  
            
        } 
            
    } else { ## mc
        one.nonpara <- function() {
            
            ## res.p <- matrix(sample(c(-1, 1), N*TT, replace = TRUE), TT, N)
            res.p <- matrix(rep(sample(c(-1, 1), N, replace = TRUE), each = TT), TT, N)
            Y.boot <- Y.f + res.p * eff
            Y.boot[which(I == 0)] <- 0
            boot <- try(fect.mc(Y = Y.boot, X = X, D = D,   
                            I = I, hasF = out$validF,
                            time.on.seq = out$time.on, time.off.seq = out$time.off,
                            force = force, lambda = out$lambda.cv, 
                            CV = 0, tol = tol, norm.para = norm.para,
                            placebo.period = NULL, hasRevs = 0))

            if ('try-error' %in% class(boot)) {
                cat("NA")
                return(NA)
            } else {
                cat(out$niter)
                cat("\n")
                data <- as.data.frame(boot$eff.pre)
                #colnames(data) <- c("period", "eff")
                data <- data[which(data[,"period"] <= pre.period[2] & data[,"period"] >= pre.period[1]),]
                lm.fit.boot <- lm(eff~factor(period), data = data)
                #f.boot <- ((sum(data[,"eff"]^2) - sum((lm.fit.boot$residuals)^2))/length(unique(data[,"period"])))/(sum((lm.fit.boot$residuals)^2)/(dim(data[1]-unique(data[,"period"]))))
                f.boot <- summary(lm.fit.boot)$f[1]
                return(f.boot)  
            }    
        } 
    }
    
    ## computing
    if (parallel == TRUE) { 
        boot.out <- foreach(j=1:nboots, 
                            .inorder = FALSE,
                            .export = c("fect.fe", "fect.mc", "get_term"),
                            .packages = c("fect")
                            ) %dopar% {
                                return(one.nonpara())
                            }

        for (j in 1:nboots) { 
            f.boot[j] <- boot.out[[j]]
        } 
    } else {
        for (j in 1:nboots) { 
            f.boot[j] <- one.nonpara() 
            ## report progress
            if (j%%100 == 0)  {
                cat(".")   
            }  
        }  
    } 
    ## end of bootstrapping
    cat("\r")

    
    f.q <- quantile(f.boot, probs = c(0.025, 0.975))
    f.p <- sum(f.boot > f)/nboots

    title <- "Empirical distribution of F under H0"
    ## plot
    f.data <- cbind.data.frame(f.boot = f.boot)
    p <- ggplot(f.data, aes(f.boot)) + geom_density() + geom_vline(xintercept = f, colour="red",size = 0.5)

    d <- ggplot_build(p)$data[[1]]

    if (f < max(d[,"x"])) {
        p <- p + geom_area(data = subset(d, x > f), aes(x=x, y=y), fill="red", alpha = 0.2)
    }

    p <- p + annotate("text", x = 0.9*max(d[,"x"]), y = 0.9*max(d[,"y"]), label = paste("P value: ", f.p, sep=""))

    p <- p + ggtitle(title) +  theme(plot.title = element_text(size=20,
                                                               hjust = 0.5,
                                                               margin = margin(10, 0, 10, 0)))

    ## suppressWarnings(print(p))
  
    ## store results
    Ftest <- matrix(NA, 1, 4)
    Ftest[1, ] <- c(f, f.q, f.p)

    colnames(Ftest) <- c("Test_statistics", "Boot_quantile_Lower", "Boot_quantile_Upper", "P_value")
    rownames(Ftest) <- "F_statistic"

    return(list(Ftest = Ftest, f.boot = f.boot, p = p))
    
} ## end of test

#####################################
## goodness of fit test: non para 
#####################################
fect.test2<-function(Y,
                     X,
                     D, ## input
                     I,
                     r=0, r.end,
                     lambda = NULL,
                     nlambda = 10,
                     method = "fe",
                     force,
                     CV, ## cross validation
                     k = 5,
                     hasRevs = 1,
                     nboots,
                     tol,
                     norm.para,
                     parallel = TRUE,
                     pre.period = NULL,
                     cores = NULL) {
    
    
    na.pos <- NULL
    TT <- dim(Y)[1]
    N <- dim(Y)[2]
    if (is.null(X) == FALSE) {
        p <- dim(X)[3]
    } else {
        p <- 0
    }

    if (hasRevs == 1) {
        ## D.fake : check reversals
        D.fake <- apply(D, 2, function(vec){cumsum(vec)})
        D.fake <- ifelse(D.fake > 0, 1, 0)
        D.fake[which(I == 0)] <- 0

        rev <- which(apply(D.fake == D, 2, sum) != TT)
        co <- which(apply(D, 2, sum) == 0)
        tr.all <- which(apply(D, 2, sum) > 0)
        tr <- tr.all[which(!tr.all %in% rev)]

        Nrev <- length(rev)
        Ntr <- length(tr)
        Nco <- length(co)
    } else {
        ## treatement indicator
        tr <- which(apply(D, 2, sum) > 0)
        co <- which(apply(D, 2, sum) == 0)

        Ntr <- length(tr)
        Nco <- length(co)
    }
    
    ## estimation
    if (method == "fe") {
        out <- fect.fe(Y = Y, X = X, D = D, I=I, r = r, r.end = r.end, 
                       force = force, CV = CV, k = k, hasRevs = 0, 
                       tol=tol, norm.para = norm.para, 
                       placebo.period = NULL)
    } else {
        out <- fect.mc(Y = Y, X = X, D = D, I = I, 
                       lambda = lambda, nlambda = nlambda, 
                       force = force, CV = CV, k = k, hasRevs = 0, 
                       tol=tol, norm.para = norm.para,
                       placebo.period = NULL)
    }

    ## output
    ## output
    validX <- out$validX
    eff <- out$eff
    att.avg <- out$att.avg

    att.on <- out$att.on
    time.on <- out$time.on

    time.off <- NULL
    if (hasRevs == 1) {
        att.off <- out$att.off
        time.off <- out$time.off
    }

    if (p > 0) {
        beta <- out$beta
    } else {
        beta <-matrix(0,1,0)
    }

    ## output
    eff <- out$eff
    eff[which(is.na(eff))] <- 0

    ## relative treatment period
    T.on <- out$T.on

    ## fitted values Y0
    Y.f <- out$est$fit

    if (is.null(pre.period)) {
        pre.period <- c(min(c(T.on), na.rm = TRUE), max(c(T.on), na.rm = TRUE))
    }

    pre.pos <- which(T.on <= pre.period[2] & T.on >= pre.period[1] & I == 1)

    ## demean pre-treatment tr eff under H0 for wild bootstrap
    #eff[pre.pos] <- eff[pre.pos] - mean(eff[pre.pos])

    ## observed F
    eff.pre <- as.data.frame(out$eff.pre)
    eff.pre <- eff.pre[which(eff.pre[,"period"] >= pre.period[1] & eff.pre[,"period"] <= pre.period[2]),]

    eff.pre[,"period"] <- as.factor(eff.pre[,"period"])
    lm.fit <- lm(eff ~ period, data = eff.pre)
    #res <- lm.fit$residuals
    #f <- ((sum(eff.pre[,"eff"]^2) - sum(res^2))/length(unique(eff.pre[,"period"])))/(sum(res^2)/(dim(eff.pre)[1] - length(unique(eff.pre[,"period"]))))
    f <- summary(lm.fit)$f[1]


    ## bootstrapped F under H0
    f.boot <- rep(NA, nboots)

    cat("\rBootstrapping ...\n")

    if (method == "fe") {
        one.nonpara <- function() {

            if (hasRevs == 0) {
                if (Nco > 0) {
                    repeat{
                        fake.co <- sample(co, Nco, replace=TRUE)
                        fake.tr <- sample(tr, Ntr, replace=TRUE)
                        boot.id <- c(fake.tr, fake.co)
                        if (sum(apply(as.matrix(I[,boot.id]),1,sum)>=1)==TT) {
                            break
                        }
                    }
                } else {
                    repeat{
                        boot.id <- sample(tr, Ntr, replace=TRUE)
                        if (sum(apply(as.matrix(I[,boot.id]),1,sum)>=1)==TT) {
                            break
                        }
                    }
                }
            } else {
                if (Ntr > 0) {
                    if (Nco > 0) {
                        repeat{
                            fake.co <- sample(co, Nco, replace=TRUE)
                            fake.tr <- sample(tr, Ntr, replace=TRUE)
                            fake.rev <- sample(rev, Nrev, replace=TRUE)
                            boot.id <- c(fake.rev, fake.tr, fake.co)
                            if (sum(apply(as.matrix(I[,boot.id]),1,sum)>=1)==TT) {
                                break
                            }
                        }
                    } else {
                        repeat{
                            fake.tr <- sample(tr, Ntr, replace=TRUE)
                            fake.rev <- sample(rev, Nrev, replace=TRUE)
                            boot.id <- c(fake.rev, fake.tr)
                            if (sum(apply(as.matrix(I[,boot.id]),1,sum)>=1)==TT) {
                                break
                            }
                        }
                    }
                } else {
                    if (Nco > 0) {
                        repeat{
                            fake.co <- sample(co, Nco, replace=TRUE)
                            fake.rev <- sample(rev, Nrev, replace=TRUE)
                            boot.id <- c(fake.rev, fake.co)
                            if (sum(apply(as.matrix(I[,boot.id]),1,sum)>=1)==TT) {
                                break
                            }
                        }
                    } else {
                        repeat{
                            boot.id <- sample(rev, Nrev, replace=TRUE)
                            if (sum(apply(as.matrix(I[,boot.id]),1,sum)>=1)==TT) {
                                break
                            }
                        }
                    }
                }
            }
                
            X.boot <- X[,boot.id,,drop=FALSE]

                
            boot <- try(fect.fe(Y[,boot.id], X.boot, D[,boot.id],
                            I = I[,boot.id],
                            force = force, r = out$r.cv, CV = 0,
                            tol = tol, time.on.seq = time.on, 
                            time.off.seq = time.off,
                            norm.para = norm.para,
                            placebo.period = NULL), silent = TRUE)

            if ('try-error' %in% class(boot)) {
                return(NA)
            } else {
                data <- as.data.frame(boot$eff.pre)
                #colnames(data) <- c("period", "eff")
                data <- data[which(data[,"period"] <= pre.period[2] & data[,"period"] >= pre.period[1]),]
                data[,"period"] <- as.factor(data[,"period"])

                eff.fit <- predict(lm.fit, data)
                ## remove pre-treatment effect
                data[,"eff0"] <- data[,"eff"] - eff.fit

                lm.fit.boot <- lm(eff0~period, data = data)
                #f.boot <- ((sum(data[,"eff"]^2) - sum((lm.fit.boot$residuals)^2))/length(unique(data[,"period"])))/(sum((lm.fit.boot$residuals)^2)/(dim(data[1]-unique(data[,"period"]))))
                f.boot <- summary(lm.fit.boot)$f[1]
                return(f.boot)  
            }
        } 
            
    } else { ## mc
        one.nonpara <- function() {

            if (hasRevs == 0) {
                if (Nco > 0) {
                    repeat{
                        fake.co <- sample(co, Nco, replace=TRUE)
                        fake.tr <- sample(tr, Ntr, replace=TRUE)
                        boot.id <- c(fake.tr, fake.co)
                        if (sum(apply(as.matrix(I[,boot.id]),1,sum)>=1)==TT) {
                            break
                        }
                    }
                } else {
                    repeat{
                        boot.id <- sample(tr, Ntr, replace=TRUE)
                        if (sum(apply(as.matrix(I[,boot.id]),1,sum)>=1)==TT) {
                            break
                        }
                    }
                }
            } else {
                if (Ntr > 0) {
                    if (Nco > 0) {
                        repeat{
                            fake.co <- sample(co, Nco, replace=TRUE)
                            fake.tr <- sample(tr, Ntr, replace=TRUE)
                            fake.rev <- sample(rev, Nrev, replace=TRUE)
                            boot.id <- c(fake.rev, fake.tr, fake.co)
                            if (sum(apply(as.matrix(I[,boot.id]),1,sum)>=1)==TT) {
                                break
                            }
                        }
                    } else {
                        repeat{
                            fake.tr <- sample(tr, Ntr, replace=TRUE)
                            fake.rev <- sample(rev, Nrev, replace=TRUE)
                            boot.id <- c(fake.rev, fake.tr)
                            if (sum(apply(as.matrix(I[,boot.id]),1,sum)>=1)==TT) {
                                break
                            }
                        }
                    }
                } else {
                    if (Nco > 0) {
                        repeat{
                            fake.co <- sample(co, Nco, replace=TRUE)
                            fake.rev <- sample(rev, Nrev, replace=TRUE)
                            boot.id <- c(fake.rev, fake.co)
                            if (sum(apply(as.matrix(I[,boot.id]),1,sum)>=1)==TT) {
                                break
                            }
                        }
                    } else {
                        repeat{
                            boot.id <- sample(rev, Nrev, replace=TRUE)
                            if (sum(apply(as.matrix(I[,boot.id]),1,sum)>=1)==TT) {
                                break
                            }
                        }
                    }
                }
            }
                
            X.boot <- X[,boot.id,,drop=FALSE]
            
            boot <- try(fect.mc(Y[,boot.id], X.boot, D[,boot.id],
                            I = I[,boot.id], hasF = out$validF,
                            time.on.seq = time.on, time.off.seq = time.off,
                            force = force, lambda = out$lambda.cv, 
                            CV = 0, tol = tol, norm.para = norm.para,
                            placebo.period = NULL), silent = TRUE)
            
            if ('try-error' %in% class(boot)) {
                return(NA)
            } else {
                data <- as.data.frame(boot$eff.pre)
                #colnames(data) <- c("period", "eff")
                data <- data[which(data[,"period"] <= pre.period[2] & data[,"period"] >= pre.period[1]),]
                data[,"period"] <- as.factor(data[,"period"])

                eff.fit <- predict(lm.fit, data)
                data[,"eff0"] <- data[,"eff"] - eff.fit

                lm.fit.boot <- lm(eff0~period, data = data)
                #f.boot <- ((sum(data[,"eff"]^2) - sum((lm.fit.boot$residuals)^2))/length(unique(data[,"period"])))/(sum((lm.fit.boot$residuals)^2)/(dim(data[1]-unique(data[,"period"]))))
                f.boot <- summary(lm.fit.boot)$f[1]
                return(f.boot) 
            }
            
        } 
    }


    
    ## computing
    if (parallel == TRUE) { 
        boot.out <- foreach(j=1:nboots, 
                            .inorder = FALSE,
                            .export = c("fect.fe", "fect.mc", "get_term"),
                            .packages = c("fect")
                            ) %dopar% {
                                return(one.nonpara())
                            }

        for (j in 1:nboots) { 
            f.boot[j] <- boot.out[[j]]
        } 
    } else {
        for (j in 1:nboots) { 
            f.boot[j] <- one.nonpara() 
            ## report progress
            if (j%%100 == 0)  {
                cat(".")   
            }  
        }  
    } 
    ## end of bootstrapping
    cat("\r")

    
    f.q <- quantile(f.boot, probs = c(0.025, 0.975))
    f.p <- sum(f.boot > f)/nboots

    title <- "Empirical distribution of F under H0"
    ## plot
    f.data <- cbind.data.frame(f.boot = f.boot)
    p <- ggplot(f.data, aes(f.boot)) + geom_density() + geom_vline(xintercept = f, colour="red",size = 0.5)

    d <- ggplot_build(p)$data[[1]]

    if (f < max(d[,"x"])) {
        p <- p + geom_area(data = subset(d, x > f), aes(x=x, y=y), fill="red", alpha = 0.2)
    }

    p <- p + annotate("text", x = 0.9*max(d[,"x"]), y = 0.9*max(d[,"y"]), label = paste("P value: ", f.p, sep=""))

    p <- p + ggtitle(title) +  theme(plot.title = element_text(size=20,
                                                               hjust = 0.5,
                                                               margin = margin(10, 0, 10, 0)))

    ## suppressWarnings(print(p))
  
    ## store results
    Ftest <- matrix(NA, 1, 4)
    Ftest[1, ] <- c(f, f.q, f.p)

    colnames(Ftest) <- c("Test_statistics", "Boot_quantile_Lower", "Boot_quantile_Upper", "P_value")
    rownames(Ftest) <- "F_statistic"

    return(list(Ftest = Ftest, f.boot = f.boot, p = p))
    
} ## end of test

###############################################
## Inference 
###############################################

fect.boot<-function(Y,
                    X,
                    D, ## input
                    I,
                    r=0, r.end,
                    lambda = NULL,
                    nlambda = 10,
                    method = "fe",
                    force,
                    CV, ## cross validation
                    k = 5,
                    hasRevs = 1,
                    nboots,
                    tol,
                    norm.para,
                    placebo.period = NULL,
                    placebo.start = NULL,
                    placeboTest = FALSE,
                    parallel = TRUE,
                    cores = NULL) {
    
    
    na.pos <- NULL
    TT <- dim(Y)[1]
    N <- dim(Y)[2]
    if (is.null(X) == FALSE) {
        p <- dim(X)[3]
    } else {
        p <- 0
    }

    if (hasRevs == 1) {
        ## D.fake : check reversals
        D.fake <- apply(D, 2, function(vec){cumsum(vec)})
        D.fake <- ifelse(D.fake > 0, 1, 0)
        D.fake[which(I == 0)] <- 0

        rev <- which(apply(D.fake == D, 2, sum) != TT)
        co <- which(apply(D, 2, sum) == 0)
        tr.all <- which(apply(D, 2, sum) > 0)
        tr <- tr.all[which(!tr.all %in% rev)]

        Nrev <- length(rev)
        Ntr <- length(tr)
        Nco <- length(co)
    } else {
        ## treatement indicator
        tr <- which(apply(D, 2, sum) > 0)
        co <- which(apply(D, 2, sum) == 0)

        Ntr <- length(tr)
        Nco <- length(co)
    }

    
    ## estimation
    if (method == "fe") {
        out <- fect.fe(Y = Y, X = X, D = D, I=I, r = r, r.end = r.end, 
                       force = force, CV = CV, k = k, hasRevs = hasRevs, 
                       tol=tol, norm.para = norm.para, 
                       placebo.period = placebo.period)
    } else {
        out <- fect.mc(Y = Y, X = X, D = D, I = I, 
                       lambda = lambda, nlambda = nlambda, 
                       force = force, CV = CV, k = k, hasRevs = hasRevs, 
                       tol=tol, norm.para = norm.para,
                       placebo.period = placebo.period)
    }

    ## output
    validX <- out$validX
    eff <- out$eff
    att.avg <- out$att.avg

    att.on <- out$att.on
    time.on <- out$time.on

    time.off <- NULL
    if (hasRevs == 1) {
        att.off <- out$att.off
        time.off <- out$time.off
    }

    if (p > 0) {
        beta <- out$beta
    } else {
        beta <-matrix(0,1,0)
    }

    ## bootstrapped estimates
    eff.boot <- array(0,dim = c(TT, Ntr, nboots))  ## to store results
    att.avg.boot <- matrix(0, nboots, 1)
    att.on.boot <- matrix(0, length(time.on), nboots)
    att.on.count.boot <- matrix(0, length(time.on), nboots)
    if (hasRevs == 1) {
        att.off.boot <- matrix(0, length(time.off), nboots) 
        att.off.count.boot <- matrix(0, length(time.off), nboots)   
    }
    if (p > 0) {
        beta.boot <- matrix(0, p, nboots)
    }
    if (!is.null(placebo.period) | placeboTest == TRUE) {
        att.placebo.boot <- matrix(0, nboots, 1)
    } 


    cat("\rBootstrapping ...\n")
 
    if (method == "fe") {
        one.nonpara <- function() {

            if (hasRevs == 0) {
                if (Nco > 0) {
                    repeat{
                        fake.co <- sample(co, Nco, replace=TRUE)
                        fake.tr <- sample(tr, Ntr, replace=TRUE)
                        boot.id <- c(fake.tr, fake.co)
                        if (sum(apply(as.matrix(I[,boot.id]),1,sum)>=1)==TT) {
                            break
                        }
                    }
                } else {
                    repeat{
                        boot.id <- sample(tr, Ntr, replace=TRUE)
                        if (sum(apply(as.matrix(I[,boot.id]),1,sum)>=1)==TT) {
                            break
                        }
                    }
                }
            } else {
                if (Ntr > 0) {
                    if (Nco > 0) {
                        repeat{
                            fake.co <- sample(co, Nco, replace=TRUE)
                            fake.tr <- sample(tr, Ntr, replace=TRUE)
                            fake.rev <- sample(rev, Nrev, replace=TRUE)
                            boot.id <- c(fake.rev, fake.tr, fake.co)
                            if (sum(apply(as.matrix(I[,boot.id]),1,sum)>=1)==TT) {
                                break
                            }
                        }
                    } else {
                        repeat{
                            fake.tr <- sample(tr, Ntr, replace=TRUE)
                            fake.rev <- sample(rev, Nrev, replace=TRUE)
                            boot.id <- c(fake.rev, fake.tr)
                            if (sum(apply(as.matrix(I[,boot.id]),1,sum)>=1)==TT) {
                                break
                            }
                        }
                    }
                } else {
                    if (Nco > 0) {
                        repeat{
                            fake.co <- sample(co, Nco, replace=TRUE)
                            fake.rev <- sample(rev, Nrev, replace=TRUE)
                            boot.id <- c(fake.rev, fake.co)
                            if (sum(apply(as.matrix(I[,boot.id]),1,sum)>=1)==TT) {
                                break
                            }
                        }
                    } else {
                        repeat{
                            boot.id <- sample(rev, Nrev, replace=TRUE)
                            if (sum(apply(as.matrix(I[,boot.id]),1,sum)>=1)==TT) {
                                break
                            }
                        }
                    }
                }
            }
                
            X.boot <- X[,boot.id,,drop=FALSE]

            if (placeboTest == TRUE & is.null(placebo.period)) {
                placebo.period.boot <- sort(unique(c(sample(placebo.start:0, 1, replace = FALSE), 0)))
            } else {
                placebo.period.boot <- placebo.period
            }
                
            boot <- try(fect.fe(Y[,boot.id], X.boot, D[,boot.id],
                            I = I[,boot.id],
                            force = force, r = out$r.cv, CV = 0,
                            tol = tol, time.on.seq = time.on, 
                            time.off.seq = time.off,
                            norm.para = norm.para,
                            placebo.period = placebo.period.boot), silent = TRUE)

            if ('try-error' %in% class(boot)) {
                boot0 <- list(att.avg = NA, att.on = NA, count.on = NA, 
                             beta = NA, att.off = NA, count.off = NA, 
                             att.placebo = NA)
                return(boot0)
            } else {
                return(boot)
            }
        } 
            
    } else { ## mc
        one.nonpara <- function() {

            if (hasRevs == 0) {
                if (Nco > 0) {
                    repeat{
                        fake.co <- sample(co, Nco, replace=TRUE)
                        fake.tr <- sample(tr, Ntr, replace=TRUE)
                        boot.id <- c(fake.tr, fake.co)
                        if (sum(apply(as.matrix(I[,boot.id]),1,sum)>=1)==TT) {
                            break
                        }
                    }
                } else {
                    repeat{
                        boot.id <- sample(tr, Ntr, replace=TRUE)
                        if (sum(apply(as.matrix(I[,boot.id]),1,sum)>=1)==TT) {
                            break
                        }
                    }
                }
            } else {
                if (Ntr > 0) {
                    if (Nco > 0) {
                        repeat{
                            fake.co <- sample(co, Nco, replace=TRUE)
                            fake.tr <- sample(tr, Ntr, replace=TRUE)
                            fake.rev <- sample(rev, Nrev, replace=TRUE)
                            boot.id <- c(fake.rev, fake.tr, fake.co)
                            if (sum(apply(as.matrix(I[,boot.id]),1,sum)>=1)==TT) {
                                break
                            }
                        }
                    } else {
                        repeat{
                            fake.tr <- sample(tr, Ntr, replace=TRUE)
                            fake.rev <- sample(rev, Nrev, replace=TRUE)
                            boot.id <- c(fake.rev, fake.tr)
                            if (sum(apply(as.matrix(I[,boot.id]),1,sum)>=1)==TT) {
                                break
                            }
                        }
                    }
                } else {
                    if (Nco > 0) {
                        repeat{
                            fake.co <- sample(co, Nco, replace=TRUE)
                            fake.rev <- sample(rev, Nrev, replace=TRUE)
                            boot.id <- c(fake.rev, fake.co)
                            if (sum(apply(as.matrix(I[,boot.id]),1,sum)>=1)==TT) {
                                break
                            }
                        }
                    } else {
                        repeat{
                            boot.id <- sample(rev, Nrev, replace=TRUE)
                            if (sum(apply(as.matrix(I[,boot.id]),1,sum)>=1)==TT) {
                                break
                            }
                        }
                    }
                }
            }
                
            X.boot <- X[,boot.id,,drop=FALSE]

            if (placeboTest == TRUE & is.null(placebo.period)) {
                placebo.period.boot <- sort(unique(c(sample(placebo.start:0, 1, replace = FALSE), 0)))
            } else {
                placebo.period.boot <- placebo.period

            }
            
            boot <- try(fect.mc(Y[,boot.id], X.boot, D[,boot.id],
                            I = I[,boot.id], hasF = out$validF,
                            time.on.seq = time.on, time.off.seq = time.off,
                            force = force, lambda = out$lambda.cv, 
                            CV = 0, tol = tol, norm.para = norm.para,
                            placebo.period = placebo.period.boot), silent = TRUE)
            if ('try-error' %in% class(boot)) {
                boot0 <- list(att.avg = NA, att.on = NA, count.on = NA, 
                             beta = NA, att.off = NA, count.off = NA, 
                             att.placebo = NA)
                return(boot0)
            } else {
                return(boot)
            }
            
        } 
    }
    
    ## computing
    if (parallel == TRUE) { 
        boot.out <- foreach(j=1:nboots, 
                            .inorder = FALSE,
                            .export = c("fect.fe", "fect.mc", "get_term"),
                            .packages = c("fect")
                            ) %dopar% {
                                return(one.nonpara())
                            }

        for (j in 1:nboots) { 
            att.avg.boot[j,] <- boot.out[[j]]$att.avg
            att.on.boot[,j] <- boot.out[[j]]$att.on 
            att.on.count.boot[,j] <- boot.out[[j]]$count.on 
            if (p > 0) {
                beta.boot[,j] <- boot.out[[j]]$beta
            }
            if (hasRevs == 1) {
                att.off.boot[,j] <- boot.out[[j]]$att.off
                att.off.count.boot[,j] <- boot.out[[j]]$count.off 
            }
            if (!is.null(placebo.period) | placeboTest == TRUE) {
                att.placebo.boot[j,] <- boot.out[[j]]$att.placebo
            } 
        } 
    } else {
        for (j in 1:nboots) { 
            boot <- one.nonpara() 
            att.avg.boot[j,] <- boot$att.avg
            att.on.boot[,j] <- boot$att.on
            att.on.count.boot[,j] <- boot$count.on 
            if (p > 0) {
                beta.boot[,j] <- boot$beta
            }
            if (hasRevs == 1) {
                att.off.boot[,j] <- boot$att.off
                att.off.count.boot[,j] <- boot$count.off 
            }
            if (!is.null(placebo.period) | placeboTest == TRUE) {
                att.placebo.boot[j,] <- boot$att.placebo
            }
            ## report progress
            if (j%%100 == 0)  {
                cat(".")   
            }  
        }  
    } 
    ## end of bootstrapping
    cat("\r")

    ## remove failure bootstrap
    if (max(apply(is.na(att.on.boot),2,sum)) == dim(att.on.boot)[1]) {
        boot.rm <- which(apply(is.na(att.on.boot),2,sum)==dim(att.on.boot)[1])
        att.avg.boot <- as.matrix(att.avg.boot[-boot.rm,])
        att.on.boot <- as.matrix(att.on.boot[,-boot.rm])
        att.on.count.boot <- as.matrix(att.on.count.boot[,-boot.rm])
        if (p > 0) {
            beta.boot <- as.matrix(beta.boot[,-boot.rm])
            if (dim(beta.boot)[2] == 1) {
                beta.boot <- t(beta.boot)
            }
        }
        if (hasRevs == 1) {
            att.off.boot <- as.matrix(att.off.boot[,-boot.rm])
            att.off.count.boot <- as.matrix(att.off.count.boot[,-boot.rm])
        }
        if (!is.null(placebo.period) | placeboTest == TRUE) {
            att.placebo.boot <- as.matrix(att.placebo.boot[-boot.rm,])
        }

    }
    cat("Actual bootstrap times: ", dim(att.on.boot)[2], "\n", sep = "")
     
    ####################################
    ## Variance and CIs
    ####################################

    ## function to get two-sided p-values
    get.pvalue <- function(vec) {
        if (NaN%in%vec|NA%in%vec) {
            nan.pos <- is.nan(vec)
            na.pos <- is.na(vec)
            pos <- c(which(nan.pos),which(na.pos))
            vec.a <- vec[-pos]
            a <- sum(vec.a >= 0)/(length(vec)-sum(nan.pos|na.pos)) * 2
            b <- sum(vec.a <= 0)/(length(vec)-sum(nan.pos|na.pos)) * 2  
        } else {
            a <- sum(vec >= 0)/length(vec) * 2
            b <- sum(vec <= 0)/length(vec) * 2  
        }
        return(min(as.numeric(min(a, b)),1))
    }

    ## ATT estimates
    CI.att.on <- t(apply(att.on.boot, 1, function(vec) quantile(vec,c(0.025,0.975), na.rm=TRUE)))
    se.att.on <- apply(att.on.boot, 1, function(vec) sd(vec, na.rm=TRUE))
    pvalue.att.on <- apply(att.on.boot, 1, get.pvalue)

    est.att.on <- cbind(att.on, se.att.on, CI.att.on, pvalue.att.on, out$count.on)
    colnames(est.att.on) <- c("ATT.ON", "S.E.", "CI.lower", "CI.upper",
                              "p.value", "count.on")
    rownames(est.att.on) <- out$time.on
    T0.on.l <- sum(out$time.on <= 0)
    norm.att.on.sq <- (att.on/se.att.on)^2
    T0.on.p <- 1 - pchisq(sum(norm.att.on.sq[1:T0.on.l]), df = T0.on.l)

    if (hasRevs == 1) {
        CI.att.off <- t(apply(att.off.boot, 1, function(vec) quantile(vec,c(0.025,0.975), na.rm=TRUE)))
        se.att.off <- apply(att.off.boot, 1, function(vec) sd(vec, na.rm=TRUE))
        pvalue.att.off <- apply(att.off.boot, 1, get.pvalue)

        est.att.off <- cbind(att.off, se.att.off, CI.att.off, pvalue.att.off, out$count.off)
        colnames(est.att.off) <- c("ATT.OFF", "S.E.", "CI.lower", "CI.upper",
                                   "p.value", "count.off")
        rownames(est.att.off) <- out$time.off
        T0.off.l <- sum(out$time.off > 0)
        norm.att.off.sq <- (att.off/se.att.off)^2
        T0.off.p <- 1 - pchisq(sum(norm.att.off.sq[(length(out$time.off) - T0.off.l + 1):length(out$time.off)]), df = T0.off.l)
    }

    ## average (over time) ATT
    CI.avg <- quantile(att.avg.boot, c(0.025,0.975), na.rm=TRUE)
    se.avg <- sd(att.avg.boot, na.rm=TRUE)
    pvalue.avg <- get.pvalue(att.avg.boot)
    est.avg <- t(as.matrix(c(att.avg, se.avg, CI.avg, pvalue.avg)))
    colnames(est.avg) <- c("ATT.avg", "S.E.", "CI.lower", "CI.upper", "p.value")

    
    ## regression coefficents
    if (p > 0) {
        CI.beta<-t(apply(beta.boot, 1, function(vec)
            quantile(vec,c(0.025, 0.975), na.rm=TRUE)))
        se.beta<-apply(beta.boot, 1, function(vec)sd(vec,na.rm=TRUE))
        pvalue.beta <- apply(beta.boot, 1, get.pvalue)
        beta[na.pos] <- NA
        est.beta<-cbind(beta, se.beta, CI.beta, pvalue.beta)
        colnames(est.beta)<-c("beta", "S.E.", "CI.lower", "CI.upper", "p.value")
    }

    ## placebo test
    if (!is.null(placebo.period) | placeboTest == TRUE) {
        if (!is.null(placebo.period)) {
            att.placebo <- out$att.placebo
        } else {
            att.placebo <- mean(att.placebo.boot)
        }
        CI.placebo <- quantile(att.placebo.boot, c(0.025,0.975), na.rm=TRUE)
        se.placebo <- sd(att.placebo.boot, na.rm=TRUE)
        pvalue.placebo <- get.pvalue(att.placebo.boot)
        est.placebo <- t(as.matrix(c(att.placebo, se.placebo, CI.placebo, pvalue.placebo)))
        colnames(est.placebo) <- c("ATT.placebo", "S.E.", "CI.lower", "CI.upper", "p.value")
    }
  
    ##storage
    result<-list(est.avg = est.avg,
                 att.avg.boot = att.avg.boot,
                 est.att.on = est.att.on,
                 att.on.boot = att.on.boot,
                 att.on.count.boot = att.on.count.boot,
                 T0.on.p = T0.on.p)
    if (p>0) {
        result <- c(result,list(beta.boot = beta.boot))
        result <- c(result,list(est.beta = est.beta))
    }
    if (hasRevs == 1) {
        result<-c(result,list(est.att.off = est.att.off, att.off.boot = att.off.boot, att.off.count.boot = att.off.count.boot, T0.off.p = T0.off.p))
    } 

    if (!is.null(placebo.period) | placeboTest == TRUE) {
        result <- c(result, list(est.placebo = est.placebo, att.placebo.boot = att.placebo.boot))
    }


    return(c(out,result))

    
} ## end of boot

##---------------------------------------##
## placebo test                          ##
##---------------------------------------##
## placeboTest  <- function(x, ## a fect object
##                          period, ## range of placebo period, length = 2
##                          ncount = 500,
##                          seed = NULL
##                         ) {
##     if (!is.null(seed)) {
##         set.seed(seed)
##     }

##     if (length(period) != 2) {
##         stop(" Length of \"period\" should equal 2.")
##     }

##     time <- x$time.on
##     p.start <- which(time == period[1])
##     p.end <- which(time == period[2])

    ## function to get two-sided p-values
##     get.pvalue <- function(vec) {
##         if (NaN%in%vec|NA%in%vec) {
##             nan.pos <- is.nan(vec)
##             na.pos <- is.na(vec)
##             pos <- c(which(nan.pos),which(na.pos))
##             vec.a <- vec[-pos]
##             a <- sum(vec.a >= 0)/(length(vec)-sum(nan.pos|na.pos)) * 2
##             b <- sum(vec.a <= 0)/(length(vec)-sum(nan.pos|na.pos)) * 2  
##         } else {
##             a <- sum(vec >= 0)/length(vec) * 2
##             b <- sum(vec <= 0)/length(vec) * 2  
##         }
##         return(min(as.numeric(min(a, b)),1))
##     }

##     att.pos <- which(time>=period[1]&time<=period[2])
##     att <- x$att.on[att.pos]
##     count <- x$count.on[att.pos]
##     rm.pos1 <- which(is.na(att))
##     rm.pos2 <- which(is.na(count))
##     if (NA %in% att | NA %in% count) {
##         att <- att[-c(rm.pos1, rm.pos2)]
##         count <- count[-c(rm.pos1, rm.pos2)]
##     }
##     catt <- sum(att*count/sum(count))

##     att.boot <- x$att.on.boot
##     count.boot <- x$att.on.count.boot
##     nboots <- dim(att.boot)[2]
##     catt.boot <- rep(NA, nboots)
##     for (i in 1:ncount) {
        ## if (p.start != p.end) {
##             pseduo.period <- sample(p.start:p.end, 2, replace = TRUE)
        ## } else {
        ##     pseduo.period <- rep(p.start, 2)
        ## }
        ## ii <- rep(1:nboots, 1, replace = FALSE)
##         ii <- as.integer(i%%nboots)
##         att.sub <- as.matrix(att.boot[min(pseduo.period):max(pseduo.period), ii])
##         count.sub <- as.matrix(count.boot[min(pseduo.period):max(pseduo.period), ii])
##         rm.pos1 <- which(is.na(att.sub))
##         rm.pos2 <- which(is.na(count.sub))
##         if (NA %in% att.sub | NA %in% count.sub) {
##             att.sub <- att.sub[-c(rm.pos1, rm.pos2)]
##             count.sub <- count.sub[-c(rm.pos1, rm.pos2)]
##         }
##         catt.boot[i] <- sum(att.sub*count.sub/sum(count.sub))
##     }
##     catt.se <- sd(catt.boot, na.rm = TRUE)
##     catt.ci <- quantile(catt.boot, c(0.025, 0.975), na.rm = TRUE)
##     catt.p <- get.pvalue(catt.boot)

##     result <- t(matrix(c(period, catt, catt.se, catt.ci, catt.p)))
##     colnames(result) <- c("start", "end", "att", "S.E.", "CI.lower", "CI.upper", "p.value")

##     return(result)
## } 

 
#######################################################
## METHODS
#######################################################

##########
## Print
##########
## a fect object
print.fect <- function(x,
                       time.on.lim = NULL,
                       time.off.lim = NULL,  
                       ...) {
    
    cat("Call:\n")
    print(x$call, digits = 4)

    if (!is.null(time.on.lim)) {

        if (is.numeric(time.on.lim)==FALSE) {
            stop("Some element in \"time.on.lim\" is not numeric.")
        } else {
            if (length(time.on.lim)!=2) {
                stop("time.on.lim must be of length 2.")
            }
        }

        seq.on.min <- min(which(x$time.on >= time.on.lim[1]))
        seq.on.max <- max(which(x$time.on <= time.on.lim[2]))
        seq.on <- seq.on.min:seq.on.max
    } else {
        seq.on <- 1:length(x$time.on)
    }

    if (is.null(x$att.off) == FALSE) {
        if (!is.null(time.off.lim)) {

            if (is.numeric(time.off.lim)==FALSE) {
                stop("Some element in \"time.off.lim\" is not numeric.")
            } else {
                if (length(time.off.lim)!=2) {
                    stop("time.off.lim must be of length 2.")
                }
            }

            seq.off.min <- min(which(x$time.off >= time.off.lim[1]))
            seq.off.max <- max(which(x$time.off <= time.off.lim[2]))
            seq.off <- seq.off.min:seq.off.max
        } else {
            seq.off <- 1:length(x$time.off)
        }    
    }
    
    if (is.null(x$est.avg) == TRUE) { # no uncertainties
        cat("\nAverage Treatment Effect:\n")
        print(x$att.avg, digits = 4)
        cat("\n   ~ Switch-on by Period:\n")
        print(x$att.on[seq.on], digits = 4)
        if (is.null(x$att.off) == FALSE) {
            cat("\n   ~ Switch-on by Period:\n")
            print(x$att.off[seq.off], digits = 4)    
        }
        if (is.null(x$X) == FALSE) {
            cat("\nCoefficients for the Covariates:\n")
            print(x$beta, digits = 4)
        }
        cat("\nUncertainty estimates not available.\n")
    } else {
        cat("\nAverage Treatment Effect:\n")
        print(x$est.avg, digits = 4)
        cat("\n   ~ Switch-on by Period:\n")
        print(x$est.att.on[seq.on,], digits = 4)
        if (is.null(x$att.off) == FALSE) {
            cat("\n   ~ Switch-on by Period:\n")
            print(x$est.att.off[seq.off,], digits = 4)    
        }
        if (is.null(x$X) == FALSE) {
            cat("\nCoefficients for the Covariates:\n")
            print(x$est.beta, digits = 4)
        }
        ## cat("\n   ~ Chi-squared test for switch-on treatment effect of pre-treatment periods:\n")
        ## cat("P =",x$T0.on.p)
        ## cat("\n   ~ Chi-squared test for switch-off treatment effect of pre-treatment periods:\n")
        ## cat("P =",x$T0.off.p)
    }

    if (!is.null(x$est.placebo)) {
        cat("\nPlacebo effect for pre-treatment periods:\n")
        print(x$est.placebo, digits = 4)
    }
}


##########
## Plot
##########
# x a fect object
# type of the plot; axes limits; axes labels; 
# main: whether to show the title;
# id: plot a part of units
plot.fect <- function(x,  
                      type = "raw",
                      gap.type = "on",
                      count = TRUE,
                      placeboTest = FALSE,
                      placebo.period = NULL,
                      xlim = NULL, 
                      ylim = NULL,
                      xlab = NULL, 
                      ylab = NULL,
                      legendOff = FALSE,
                      main = NULL,
                      id = NULL,
                      axis.adjust = FALSE,
                      axis.lab = "both",
                      axis.lab.gap = c(0, 0),
                      ...){
    ##-------------------------------##
    ## Checking Parameters
    ##-------------------------------## 
    p <- NULL
    outcome <- NULL ## global variable
    labels1 <- labels2 <- labels3 <- NULL
    ATT.OFF <- ATT.ON <- CI.lower <- CI.upper <- NULL
    xmax <- xmin <- ymax <- ymin <- NULL

    if (class(x) != "fect") {
        stop("Not a \"fect\" object.")
    }
    if (!type %in% c("missing", "raw", "gap")) {
        stop("\"type\" option misspecified.")
    }

    if (type == "gap" && gap.type == "off" && is.null(x$att.off)) {
        stop("No switch off treatment effect to be plotted.")
    }
    
    if (is.null(xlim)==FALSE) {
        if (is.numeric(xlim)==FALSE) {
            stop("Some element in \"xlim\" is not numeric.")
        } else {
            if (length(xlim)!=2) {
                stop("xlim must be of length 2.")
            }
        }
    }
    if (is.null(ylim)==FALSE) {
        if (is.numeric(ylim)==FALSE) {
            stop("Some element in \"ylim\" is not numeric.")
        } else {
            if (length(ylim)!=2) {
                stop("ylim must be of length 2.")
            }
        }
    }
    if (is.null(xlab)==FALSE) {
        if (is.character(xlab) == FALSE) {
            stop("\"xlab\" is not a string.")
        } else {
            xlab <- xlab[1]
        }   
    }
    if (is.null(ylab)==FALSE) {
        if (is.character(ylab) == FALSE) {
            stop("\"ylab\" is not a string.")
        } else {
            ylab <- ylab[1]
        }   
    }
    if (is.logical(legendOff) == FALSE & is.numeric(legendOff)==FALSE) {
        stop("\"legendOff\" is not a logical flag.")
    }

    if (is.null(main)==FALSE) {
        if (is.character(main) == FALSE) {
            stop("\"main\" is not a string.")
        } else {
            main <- main[1]
        }   
    }

    if (axis.adjust == TRUE) {
        angle <- 45
        x.v <- 1
        x.h <- 1
    } else {
        angle <- 0
        x.v <- 0
        if (type == "missing") {
            x.h <- 0.5
        } else {
            x.h <- 0
        }
    }

    ##-------------------------------##
    ## Plotting
    ##-------------------------------## 

    Y <- x$Y.dat
    D <- x$D.dat
    I <- x$I.dat
    Yname <- x$Y

    index <- x$index
    unit.type <- x$unit.type
    obs.missing <- x$obs.missing
    tname <- time <- x$time

    TT <- dim(Y)[1]
    N <- dim(Y)[2]

    if (type == "missing") {
        if (is.null(id) == TRUE) {
            ## if (is.null(show.id) == TRUE) {
                id <- colnames(obs.missing)
            ## } else {
            ##     id <- colnames(obs.missing)[show.id]
            ## }
        }
        m.l <- length(id)
        for (i in 1:m.l) {
            if (!id[i]%in%colnames(obs.missing)) {
                stop("Some specified units are not in the data.")
            }
        }
    } else { ## raw plot
        if (is.null(id) == TRUE) {
            ## if (is.null(show.id) == TRUE) {
                id <- x$id
            ## } else {
            ##     id <- colnames(obs.missing)[show.id]
            ## }
        }
        m.l <- length(id)
        id.pos <- rep(NA, m.l)
        for (i in 1:m.l) {
            if (!id[i] %in% x$id) {
                stop("Some specified units are not in the data.")
            } else {
                id.pos[i] <- which(x$id == id[i])
            }
        }
        Y <- as.matrix(Y[, id.pos])
        I <- as.matrix(I[, id.pos])
        D <- as.matrix(D[, id.pos])
        unit.type <- unit.type[id.pos]
    }
  
    ## type of plots
    if (type == "gap") {
        if (gap.type == "on") {
            time <- x$time.on
        } else {
            time <- x$time.off
        }
    } else {
        if (!is.numeric(time[1])) {
            time <- 1:TT
        }
    }

    ## periods to show
    if (length(xlim) != 0) {
        show <- which(time>=xlim[1] & time<=xlim[2])
    } else {
        show <- 1:length(time)
    }     

    nT <- length(show)
    time.label <- tname[show]
    T.b <- 1:length(show)
 
    ## legend on/off
    if (legendOff == TRUE) {
        legend.pos <- "none"
    } else {
        legend.pos <- "bottom"
    }


    ############  START  ############### 
    if (type == "gap") {
        ## axes labels
        if (is.null(xlab) == TRUE) {
            xlab <- paste("Time relative to Treatment")
        } else if (xlab == "") {
            xlab <- NULL
        }
    
        if (is.null(ylab) == TRUE) {
            ylab <- "Coefficient"
        } else if (ylab == "") {
            ylab <- NULL
        }
            
        ## title
        maintext <- "Estimated Average Treatment Effect"
            
        if (gap.type == "on") {
            if (is.null(x$est.att.on)==TRUE) { 
                cat("Uncertainty estimates not available.\n")
                data <- cbind.data.frame(time, ATT.ON = x$att.on, count = x$count.on)[show,]
                ## rect.length <- (max(data[,"ATT.ON"]) - min(data[,"ATT.ON"]))/2
                if (length(ylim) != 0) {
                    rect.length <- (ylim[2] - ylim[1]) / 5
                    rect.min <- ylim[1]
                } else {
                    rect.length <- (max(data[,"ATT.ON"]) - min(data[,"ATT.ON"]))/2
                    rect.min <- min(data[,"ATT.ON"]) - rect.length
                }    

            } else {
                tb <- x$est.att.on
                data <- cbind.data.frame(time, tb, count = x$count.on)[show,]
                ## rect.length <- (max(data[,"CI.upper"]) - min(data[,"CI.lower"]))/2
                if (length(ylim) != 0) {
                    rect.length <- (ylim[2] - ylim[1]) / 5
                    rect.min <- ylim[1]
                } else {
                    rect.length <- (max(data[,"CI.upper"]) - min(data[,"CI.lower"]))/2
                    rect.min <- min(data[,"CI.lower"]) - rect.length
                }  
                if (placeboTest == TRUE) {
                    data[,"ATT.ON4"] <- data[,"ATT.ON3"] <- data[,"ATT.ON2"] <- data[,"ATT.ON"]
                    data[,"CI.lower4"] <- data[,"CI.lower3"] <- data[,"CI.lower2"] <- data[,"CI.lower"]
                    data[,"CI.upper4"] <- data[,"CI.upper3"] <- data[,"CI.upper2"] <- data[,"CI.upper"]
                    
                    #pos1 <- which(data[,"time"] <= -1)
                    #pos2 <- which(data[,"time"] >= 0)

                    pos1 <- intersect(which(data[,"time"] >= (placebo.period[1] + 1)), which(data[,"time"] <= (placebo.period[2] - 1)))
                    pos2 <- c(which(data[,"time"] <= (placebo.period[1] - 1)), which(data[,"time"] >= (placebo.period[2] + 1)))

                    pos3 <- intersect(which(data[,"time"] >= (placebo.period[1])), which(data[,"time"] <= (placebo.period[2] - 1)))
                    pos4 <- c(which(data[,"time"] <= (placebo.period[1] - 2)), which(data[,"time"] >= (placebo.period[2] + 1)))
                    
                    data[pos1, c("ATT.ON","CI.lower","CI.upper")] <- NA
                    data[pos2, c("ATT.ON2","CI.lower2","CI.upper2")] <- NA
                    data[pos3, c("ATT.ON3","CI.lower3","CI.upper3")] <- NA
                    data[pos4, c("ATT.ON4","CI.lower4","CI.upper4")] <- NA
                }

            }
             
            ## plotting
            p <- ggplot(data) +
                    geom_vline(xintercept = 0, colour="white",size = 2) +
                    geom_hline(yintercept = 0, colour="white",size = 2) +
                    ## annotate("rect", xmin= time.bf, xmax= Inf,
                    ##          ymin=-Inf, ymax=Inf, alpha = .1,
                    ##          fill = "yellow") +
                    xlab(xlab) +  ylab(ylab) +
                    theme(legend.position = legend.pos,
                          axis.text.x=element_blank(),
                          axis.ticks.x=element_blank(),
                          axis.title=element_text(size=20),
                          axis.text=element_text(size=20),
                          plot.title = element_text(size=20,
                                                    hjust = 0.5,
                                                    face="bold",
                                                    margin = margin(10, 0, 10, 0)))
           
            ## point estimates
            if (placeboTest == FALSE) {
                p <- p + geom_line(aes(time, ATT.ON), size = 1.2)
            } else {
                p <- p + geom_line(aes(time, ATT.ON3), size = 0.7)
                p <- p + geom_line(aes(time, ATT.ON4), size = 0.7, colour = "#4671D5")

                p <- p + geom_point(aes(time, ATT.ON), size = 1.2)
                p <- p + geom_point(aes(time, ATT.ON2), size = 1.2, colour = "#4671D5")
            }
             
            ## confidence intervals
            if (is.null(x$est.att.on)==FALSE) {
                if (placeboTest == FALSE) {
                    p <- p + geom_ribbon(aes(x = time, ymin=CI.lower, ymax=CI.upper),alpha=0.2)
                } else {
                    p <- p + geom_ribbon(aes(x = time, ymin=CI.lower3, ymax=CI.upper3),alpha=0.2)
                    p <- p + geom_ribbon(aes(x = time, ymin=CI.lower4, ymax=CI.upper4),alpha=0.2, fill = "#0000FF")
                    p.label <- paste("p value: ", sprintf("%.3f",x$est.placebo[5]), sep="")
                    p <- p + annotate("text", x = 0, y = ifelse(length(ylim) != 0, 0.75*abs(ylim[2]), max(data[,"CI.upper"], na.rm = 1)), label = p.label, size = 5)

                }
            }

            if (count == TRUE) {
                data[,"xmin"] <- data[,"time"] - 0.2
                data[,"xmax"] <- data[,"time"] + 0.2
                data[,"ymin"] <- rep(rect.min, dim(data)[1])
                data[,"ymax"] <- rect.min + (data[,"count"]/max(data[,"count"])) * 0.8 * rect.length
                p <- p + geom_rect(data = data, aes(xmin = xmin, xmax = xmax, ymin = ymin, ymax = ymax), fill = "grey70", colour = "grey69", alpha = 0.4, size = 0.2)
            }

        } else {
            ## switch.off
            if (is.null(x$est.att.off)==TRUE) { 
                cat("Uncertainty estimates not available.\n")
                data <- cbind.data.frame(time, ATT.OFF = x$att.off, count = x$count.off)[show,]
                ## rect.length <- (max(data[,"ATT.OFF"]) - min(data[,"ATT.OFF"]))/2 
                if (length(ylim) != 0) {
                    rect.length <- (ylim[2] - ylim[1]) / 5
                    rect.min <- ylim[1]
                } else {
                    rect.length <- (max(data[,"ATT.OFF"]) - min(data[,"ATT.OFF"]))/2 
                    rect.min <- min(data[,"ATT.OFF"]) - rect.length
                }  

            } else {
                tb <- x$est.att.off
                data <- cbind.data.frame(time, tb, count = x$count.off)[show,]
                ## rect.length <- (max(data[,"CI.upper"]) - min(data[,"CI.lower"]))/2
                if (length(ylim) != 0) {
                    rect.length <- (ylim[2] - ylim[1]) / 5
                    rect.min <- ylim[1]
                } else {
                    rect.length <- (max(data[,"CI.upper"]) - min(data[,"CI.lower"]))/2
                    rect.min <- min(data[,"CI.lower"]) - rect.length
                }  
            }
             
            ## plotting
            p <- ggplot(data) +
                    geom_vline(xintercept = 0, colour="white",size = 2) +
                    geom_hline(yintercept = 0, colour="white",size = 2) +
                    ## annotate("rect", xmin= time.bf, xmax= Inf,
                    ##          ymin=-Inf, ymax=Inf, alpha = .1,
                    ##          fill = "yellow") +
                    xlab(xlab) +  ylab(ylab) +
                    theme(legend.position = legend.pos,
                          axis.text=element_text(size=20),
                          plot.title = element_text(size=20,
                                                    hjust = 0.5,
                                                    face="bold",
                                                    margin = margin(10, 0, 10, 0)))
           
            ## point estimates
            p <- p + geom_line(aes(time, ATT.OFF), size = 1.2)
             
            ## confidence intervals
            if (is.null(x$est.att.off)==FALSE) {
                p <- p + geom_ribbon(aes(x = time, ymin=CI.lower, ymax=CI.upper),alpha=0.2)
            }

            if (count == TRUE) {
                data[,"xmin"] <- data[,"time"] - 0.2
                data[,"xmax"] <- data[,"time"] + 0.2
                data[,"ymin"] <- rep(rect.min, dim(data)[1])
                data[,"ymax"] <- rect.min + (data[,"count"]/max(data[,"count"])) * 0.8 * rect.length
                p <- p + geom_rect(data = data, aes(xmin = xmin, xmax = xmax, ymin = ymin, ymax = ymax), fill = "grey70", colour = "grey69", alpha = 0.4, size = 0.2)
            }

        }
            
        ## title
        if (is.null(main) == TRUE) {
            p <- p + ggtitle(maintext)
        } else if (main!=""){
            p <- p + ggtitle(main)
        }

        ## ylim
        if (is.null(ylim) == FALSE) {
            p <- p + coord_cartesian(ylim = ylim)
        }
        suppressWarnings(print(p))
    }
    else if (type == "raw") {

        ## axes labels
        if (is.null(xlab)==TRUE) {
            xlab <- index[2]
        } else if (xlab == "") {
            xlab <- NULL
        }
        if (is.null(ylab)==TRUE) {
            ylab <- Yname
        } else if (ylab == "") {
            ylab <- NULL
        }

        if (is.null(ylim) == TRUE) {
            ylim <- c(min(c(Y[show,]), na.rm = TRUE), max(c(Y[show,]), na.rm = TRUE))
        }

        if (is.null(main) == TRUE) {
            main <- "Raw Data"
        }

        ## if (!is.null(legend.labs)) {
        ##     if (length(legend.labs) != 2) {
        ##         warning("Wrong number of labels in the legend. Using default.\n")
        ##         set.labels = c("Control", "Treatment") 
        ##     } else {
        ##         set.labels <- legend.labs
        ##     }
        ## } else {
            set.labels = c("Control", "Treatment") 
        ## } 

            
        if (1 %in% unit.type) {
            co.pos <- which(unit.type == 1)
            Nco <- length(co.pos)
            data1 <- cbind.data.frame("time" = c(rep(time[show], Nco)),
                                      "outcome" = c(Y[show, co.pos]),
                                      "type" = c(rep("co", (Nco*nT))),
                                      "id" = c(rep(1:Nco, each = nT)))
            limits1 <- c("co", "tr")
            #limits1 <- "co"
            colors1 <- c("#99999950", "#FC8D6280")
            #colors1 <- "#99999950"
            ## main1 <- main
            main1 <- "Always Under Control"
        }

        if (2 %in% unit.type) {
            tr.pos <- which(unit.type == 2)
            Ntr <- length(tr.pos)
            data2 <- cbind.data.frame("time" = c(rep(time[show], Ntr)),
                                      "outcome" = c(Y[show, tr.pos]),
                                      "type" = c(rep("tr",(Ntr*nT))),
                                      "id" = c(rep(1:Ntr,each = nT)))
            limits2 <- c("co", "tr")
            #limits2 <- "tr"
            colors2 <- c("#99999950", "#FC8D6280") 
            #colors2 <- "#FC8D6280" 
            ## main2 <- ifelse(1%in%unit.type, "", main)
            main2 <- "Always Under Treatment"
        }

        if (3 %in% unit.type) {
            rv.pos <- which(unit.type == 3)
            Nrv <- length(rv.pos)

            D.plot <- D

            D.plot[which(D.plot == 0)] <- NA
            D.plot[which(I == 0)] <- NA

            D.rv <- as.matrix(D.plot[, rv.pos])
            Y.rv <- as.matrix(Y[, rv.pos])

            Y.trt <- Y.rv * D.rv
            Y.trt.show <- as.matrix(Y.trt[show,])
            time.trt.show <- time[show]
            ut.time <- ut.id <- NULL
            for (i in 1:Nrv) {
                if (sum(is.na(Y.trt.show[,i])) != nT) {
                    ut.id <- c(ut.id, rep(i, nT - sum(is.na(Y.trt.show[,i]))))
                    ut.time <- c(ut.time, time.trt.show[which(!is.na(Y.trt.show[,i]))])
                }
            }


            data3 <- cbind.data.frame("time" = c(rep(time[show], Nrv), ut.time),
                                      "outcome" = c(c(Y[show, rv.pos]),
                                                  c(Y.trt.show[which(!is.na(Y.trt.show))])),
                                      "type" = c(rep("nut",(Nrv*nT)),
                                               rep("ut",length(ut.id))),
                                      "id" = c(rep(1:Nrv,each = nT), ut.id))
            limits3 <- c("nut", "ut")
            colors3 <- c("#99999950", "#FC8D6280")
            main3 <- "Treatment Status Changed"
        }
            
        subplot <- function (data, limits, labels, colors, main) {
            ## theme
            p <- ggplot(data) + xlab(xlab) +  ylab(ylab) +
                theme(axis.text.x = element_text(angle = angle, hjust=x.h, vjust=x.h),
                      plot.title = element_text(size=10,
                                                hjust = 0.5,
                                                margin = margin(10, 0, 10, 0)))

            ## main
            p <- p + geom_line(aes(time, outcome,
                                   colour = type,
                                   size = type,
                                   linetype = type,
                                   group = id))

            ## legend
            set.limits = limits
            set.colors = colors
            set.linetypes = rep("solid", length(limits))
            set.linewidth = rep(0.5, length(limits))

            p <- p + scale_colour_manual(limits = set.limits,
                                         labels = set.labels,
                                         values =set.colors) +
                    scale_linetype_manual(limits = set.limits,
                                          labels = set.labels,
                                          values = set.linetypes) +
                    scale_size_manual(limits = set.limits,
                                      labels = set.labels,
                                      values = set.linewidth) +
                    guides(linetype = guide_legend(title=NULL, nrow=1),
                           colour = guide_legend(title=NULL, nrow=1),
                           size = guide_legend(title=NULL, nrow=1)) 
        
            if (!is.numeric(time.label)) {
                p <- p + 
                    scale_x_continuous(expand = c(0, 0), breaks = show[T.b], labels = time.label[T.b])
            }

            ## title
            if (is.null(main) == TRUE) {
                p <- p + ggtitle("Raw Data")
            } else if (main!="") {
                p <- p + ggtitle(main)
            }

            ## ylim
            if (is.null(ylim) == FALSE) {
                p <- p + coord_cartesian(ylim = ylim)
            }
            return(p)
        }

        if (length(unique(unit.type))==1) {
            if (1%in%unit.type) {
                p1 <- subplot(data1, limits1, labels1, colors1, main1)
                if (legend.pos != "none") {
                    suppressWarnings(g <- ggplotGrob(p1 + theme(legend.position="bottom"))$grobs)
                    legend <- g[[which(sapply(g, function(x) x$name) == "guide-box")]]
                    suppressWarnings(grid.arrange(arrangeGrob(p1 + theme(legend.position="none"),
                                     legend, nrow = 2, heights = c (1, 1/5)),
                                     top = textGrob(main, gp = gpar(fontsize=20,font=2))))
                } else {
                    suppressWarnings(grid.arrange(p1 + theme(legend.position="none"),
                                     top = textGrob(main, gp = gpar(fontsize=20,font=2))))
                }   
            }
            else if (2%in%unit.type) {
                p2 <- subplot(data2, limits2, labels2, colors2, main2)
                if (legend.pos != "none") {
                    suppressWarnings(g <- ggplotGrob(p2 + theme(legend.position="bottom"))$grobs)
                    legend <- g[[which(sapply(g, function(x) x$name) == "guide-box")]]
                    suppressWarnings(grid.arrange(arrangeGrob(p2 + theme(legend.position="none"),
                                     legend, nrow = 2, heights = c (1, 1/5)),
                                     top = textGrob(main, gp = gpar(fontsize=20,font=2)))) 
                } else {
                    suppressWarnings(grid.arrange(p2 + theme(legend.position="none"),
                                     top = textGrob(main, gp = gpar(fontsize=20,font=2))))
                }   
            }
            else if (3%in%unit.type) {
                p3 <- subplot(data3, limits3, labels3, colors3, main3)
                if (legend.pos != "none") {
                    suppressWarnings(g <- ggplotGrob(p3 + theme(legend.position="bottom"))$grobs)
                    legend <- g[[which(sapply(g, function(x) x$name) == "guide-box")]]
                    suppressWarnings(grid.arrange(arrangeGrob(p3 + theme(legend.position="none"),
                                     legend, nrow = 2, heights = c (1, 1/5)),
                                     top = textGrob(main, gp = gpar(fontsize=20,font=2)))) 
                } else {
                    suppressWarnings(grid.arrange(p3 + theme(legend.position="none"),
                                     top = textGrob(main, gp = gpar(fontsize=20,font=2))))
                }  
            }
        }
        else if (length(unique(unit.type))==2) {
            if (!1%in%unit.type) {
                p2 <- subplot(data2, limits2, labels2, colors2, main2)
                p3 <- subplot(data3, limits3, labels3, colors3, main3)
                if (legend.pos != "none") {
                    suppressWarnings(g <- ggplotGrob(p2 + theme(legend.position="bottom"))$grobs)
                    legend <- g[[which(sapply(g, function(x) x$name) == "guide-box")]]
                    suppressWarnings(grid.arrange(arrangeGrob(p2 + theme(legend.position="none"), p3 + theme(legend.position="none"),
                                     legend, nrow = 3, heights = c (1, 1, 1/5)),
                                     top = textGrob(main, gp = gpar(fontsize=20,font=2))))  
                } else {
                    suppressWarnings(grid.arrange(p2 + theme(legend.position="none"),
                                     p3 + theme(legend.position="none"),
                                     top = textGrob(main, gp = gpar(fontsize=20,font=2))))
                }  
            }
            else if (!2%in%unit.type) {
                p1 <- subplot(data1, limits1, labels1, colors1, main1)
                p3 <- subplot(data3, limits3, labels3, colors3, main3)
                if (legend.pos != "none") {
                    suppressWarnings(g <- ggplotGrob(p1 + theme(legend.position="bottom"))$grobs)
                    legend <- g[[which(sapply(g, function(x) x$name) == "guide-box")]]
                    suppressWarnings(grid.arrange(arrangeGrob(p1 + theme(legend.position="none"), p3 + theme(legend.position="none"),
                                     legend, nrow = 3, heights = c (1, 1, 1/5)),
                                     top = textGrob(main, gp = gpar(fontsize=20,font=2))))  
                } else {
                    suppressWarnings(grid.arrange(p1 + theme(legend.position="none"),
                                     p3 + theme(legend.position="none"),
                                     top = textGrob(main, gp = gpar(fontsize=20,font=2))))
                }  
            }
            else if (!3%in%unit.type) {
                p1 <- subplot(data1, limits1, labels1, colors1, main1)
                p2 <- subplot(data2, limits2, labels2, colors2, main2)
                if (legend.pos != "none") {
                    suppressWarnings(g <- ggplotGrob(p1 + theme(legend.position="bottom"))$grobs)
                    legend <- g[[which(sapply(g, function(x) x$name) == "guide-box")]]
                    suppressWarnings(grid.arrange(arrangeGrob(p1 + theme(legend.position="none"), p2 + theme(legend.position="none"),
                                     legend, nrow = 3, heights = c (1, 1, 1/5)),
                                     top = textGrob(main, gp = gpar(fontsize=20,font=2))))  
                } else {
                    suppressWarnings(grid.arrange(p1 + theme(legend.position="none"),
                                     p2 + theme(legend.position="none"),
                                     top = textGrob(main, gp = gpar(fontsize=20,font=2))))
                }   
            }
        }
        else {
            p1 <- subplot(data1, limits1, labels1, colors1, main1)
            p2 <- subplot(data2, limits2, labels2, colors2, main2)
            p3 <- subplot(data3, limits3, labels3, colors3, main3)
            if (legend.pos != "none") {
                suppressWarnings(g <- ggplotGrob(p1 + theme(legend.position="bottom"))$grobs)
                legend <- g[[which(sapply(g, function(x) x$name) == "guide-box")]]
                suppressWarnings(grid.arrange(arrangeGrob(p1 + theme(legend.position="none"), p2 + theme(legend.position="none"),
                                 p3 + theme(legend.position="none"), legend, nrow = 4, heights = c (1, 1, 1, 1/5)),
                                 top = textGrob(main, gp = gpar(fontsize=20,font=2))))
            } else {
                suppressWarnings(grid.arrange(p1 + theme(legend.position="none"),
                                     p2 + theme(legend.position="none"),
                                     p3 + theme(legend.position="none"),
                                     top = textGrob(main, gp = gpar(fontsize=20,font=2))))
            }
        }
        ## end of raw plot
        
    } else if (type=="missing") {
        
        if (is.null(xlab)==TRUE) {
            xlab <- index[2]
        } else if (xlab == "") {
            xlab <- NULL
        }
        if (is.null(ylab)==TRUE) {
            ylab <- index[1]
        } else if (ylab == "") {
            ylab <- NULL
        }
        if (is.null(main)==TRUE) {
            main <- "Treatment Status"
        } else if (main == "") {
            main <- NULL
        }

        m <- obs.missing
        m <- as.matrix(m[show,which(colnames(m)%in%id)])

        all <- unique(c(m))
        col <- col2 <- breaks <- label <- NULL

        if (1%in%all) {
            col <- c(col,"#06266F")
            col2 <- c(col2, "1"=NA)
            breaks <- c(breaks,1)
            label <- c(label,"Under Treatment")
        }
        if (2%in%all) {
            col <- c(col,"#B0C4DE")
            col2 <- c(col2, "2"=NA)
            breaks <- c(breaks,2)
            label <- c(label,"Under Control")
        }
        if (3%in%all) {
            col <- c(col,"#FFFFFF")
            col2 <- c(col2, "3"=NA)
            breaks <- c(breaks,3)
            label <- c(label,"Missing")
        }
        if (4%in%all) {
            col <- c(col,"#A9A9A9")
            col2 <- c(col2, "4"="red")
            breaks <- c(breaks,4)
            label <- c(label,"Treated (Removed)")
        }

        ## if (!is.null(legend.labs)) {
        ##     if (length(legend.labs) != length(all)) {
        ##         warning("Wrong number of labels in the legend. Using default.\n")
        ##     } else {
        ##         label <- legend.labs
        ##     }
        ## } 
        
        TT <- dim(m)[1]
        N <- dim(m)[2]
        units <- rep(rev(1:N), each = TT)
        period <- rep(1:TT, N)
        res <- c(m)
        data <- cbind.data.frame(units=units, period=period, res=res)
        data[,"res"] <- as.factor(data[,"res"])

        ## check if N >= 200
        if (dim(m)[2] >= 200) {
            if (axis.lab == "both") {
                axis.lab <- "time"
            }
            else if (axis.lab == "unit") {
                axis.lab <- "off"
            }
        }

        ## labels
        N.b <- 1:N
        if (axis.lab == "both") {
            if (length(axis.lab.gap)==2) {
                x.gap <- axis.lab.gap[1]
                y.gap <- axis.lab.gap[2] 
            } else {
                x.gap <- y.gap <- axis.lab.gap[1]
            }
        } else {
            x.gap <- y.gap <- axis.lab.gap[1]
        }

        if (x.gap != 0) {
            T.b <- seq(from = 1, to = length(show), by = (x.gap + 1))
        }
        if (y.gap != 0) {
            N.b <- seq(from = N, to = 1, by = -(y.gap + 1))
        }
        id <- rev(id)
        
        p <- ggplot(data, aes(x = period, y = units,
                              fill = res), position = "identity") 
        p <- p + geom_tile(colour="gray90", size=0.1, stat="identity") 
  
        p <- p +
            labs(x = xlab, y = ylab,  
                title=main) +
            theme_bw() + 
            scale_fill_manual(NA, breaks = breaks, values = col, labels=label)

        if(4%in%all) {
            p <- p + geom_point(aes(colour=res),size=0.5)
            p <- p + scale_color_manual(NA, breaks=breaks,
                                        values=col2, labels=label)
        }

        p <- p +
        theme(panel.grid.major = element_blank(),
              panel.grid.minor = element_blank(),
              panel.border = element_rect(fill=NA,color="gray90", size=0.5, linetype="solid"),
              axis.line = element_blank(),
              axis.ticks = element_blank(),
              axis.text = element_text(color="black", size=14),
              axis.title=element_text(size=12),
              axis.text.x = element_text(size = 8, angle = angle, hjust=x.h, vjust=x.v),
              axis.text.y = element_text(size = 8),
              plot.background = element_rect(fill = "grey90"),
              legend.background = element_rect(fill = "grey90"),
              legend.position = legend.pos,
              legend.title=element_blank(),
              plot.title = element_text(size=20,
                                        hjust = 0.5,
                                        face="bold",
                                        margin = margin(10, 0, 10, 0)))
        if (axis.lab == "both") {
            p <- p + scale_x_continuous(expand = c(0, 0), breaks = T.b, labels = time.label[T.b]) +
            scale_y_continuous(expand = c(0, 0), breaks = N.b, labels = id[N.b])
        }
        else if (axis.lab == "unit") {
            p <- p + scale_x_continuous(expand = c(0, 0), breaks = T.b, labels = NULL) +
            scale_y_continuous(expand = c(0, 0), breaks = N.b, labels = id[N.b])            
        }
        else if (axis.lab == "time") {
            p <- p + scale_x_continuous(expand = c(0, 0), breaks = T.b, labels = time.label[T.b]) +
            scale_y_continuous(expand = c(0, 0), breaks = N.b, labels = NULL)
        }
        else if (axis.lab == "off") {
            p <- p + scale_x_continuous(expand = c(0, 0), breaks = 1:length(show), labels = NULL) +
            scale_y_continuous(expand = c(0, 0), breaks = 1:N, labels = NULL)
        }
        
        if(length(all)>=4) {
            p <- p + guides(fill=guide_legend(nrow=2,byrow=TRUE))
        }
        suppressWarnings(print(p))
        ## end of missing plot
    }
    ## return(p)       
}

#################################
## support function
#################################
get_term <- function(d,
                     ii, 
                     type = "on") {
    dd <- d
    iii <- ii
    ## dd <- dd[which(iii == 1)]
    first.pos <- min(which(iii == 1))
    if (first.pos != 1) {
        dd <- dd[-(1:(first.pos-1))]
        iii <- iii[-(1:(first.pos-1))]
    } 
    T <- length(dd) 
    if (0 %in% iii) {
        if (T > 1) {
            for (i in 1:(T-1)) {
                if (iii[i+1] == 0) {
                    dd[i+1] <- dd[i]
                }
            }
        }
    }

    if (type == "off") {
        dd <- abs(dd - 1)
    }
    d1 <- dd[1:(T-1)]
    d2 <- dd[2:T]
    if (sum(d1 == d2) == (T-1)) {
        term <- rep(NA, T)
    } else {
        change.pos <- which(d1 != d2) + 1
        change.length <- length(change.pos)
        term <- NULL    
        if (dd[1] == 0) {   
            for (i in 1:(change.length)) {
                if (i == 1) {
                    part.term <- (2 - change.pos[i]):0
                } else {
                    if (i %% 2 == 0) {
                        part.term <- 1:(change.pos[i] - change.pos[i-1])
                    } else {
                        part.term <- (change.pos[i-1] - change.pos[i] + 1):0
                    }
                }
                term <- c(term, part.term)
            }
        } else if (dd[1] == 1) {
            for (i in 1:(change.length)) {
                if (i == 1) {
                    if (type == "on") {
                        part.term <- 1:(change.pos[i] - 1)
                    } else if (type == "off") {
                        part.term <- rep(NA, change.pos[i] - 1)
                    }
                } else {
                    if (i %% 2 == 0) {
                        part.term <- (change.pos[i-1] - change.pos[i] + 1):0
                    } else {
                        part.term <- 1:(change.pos[i] - change.pos[i-1])
                    }
                }
                term <- c(term, part.term)
            }
        } 
        if (dd[change.pos[change.length]] == 0) {
            term <- c(term, rep(NA, (T - change.pos[change.length] + 1)))
        } else {
            term <- c(term, 1:(T - change.pos[change.length] + 1))
        }
    }
    ## term.all <- rep(NA, length(d))
    if (first.pos != 1) {
        term <- c(rep(NA, (first.pos - 1)), term)
    }
    return(term)
}

###################################
## fastplm for initial values
###################################

initialFit <- function(data, ## long form data 
                       force,
                       oci ) { ## indicator

    p <- dim(data)[2] - 3

    data2 <- as.data.frame(data)
    colnames.data2 <- c("y","id","time")

    data2[,2] <- as.factor(data2[,2])
    data2[,3] <- as.factor(data2[,3])

    x.name <- NULL
    if (p > 0) {
        for (i in 1:p) {
            x.name <- c(x.name, paste("x", i, sep = ""))
        }
        colnames.data2 <- c(colnames.data2, x.name)
    }

    colnames(data2) <- colnames.data2

    if (p > 0) {
        if (force == 1) {
            Fit.formula <- paste0("y ~", paste0(x.name, collapse = "+"), "+ id")
        } 
        else if (force == 2) {
            Fit.formula <- paste0("y ~", paste0(x.name, collapse = "+"), "+ time")
        }
        else if (force == 3) {
            Fit.formula <- paste0("y ~", paste0(x.name, collapse = "+"), "+ id + time")
        }
        else {
            Fit.formula <- paste0("y ~", paste0(x.name, collapse = "+"))
        }
    } else {
        if (force == 1) {
            Fit.formula <- paste0("y ~ id")
        } 
        else if (force == 2) {
            Fit.formula <- paste0("y ~ time")
        }
        else if (force == 3) {
            Fit.formula <- paste0("y ~ id + time")
        }
        else {
            Fit.formula <- paste0("y ~ 1")
        }
    }
    N <- length(unique(data[,2]))
    T <- length(unique(data[,3]))
    lfit <- lm(as.formula(Fit.formula), data = data2[oci,])
    Y0 <- matrix(predict(lfit, data2), T, N)
    if (p > 0) {
        beta0 <- as.matrix(lfit$coefficients[2:(p+1)])
        if (sum(is.na(beta0)) > 0) {
            beta0[which(is.na(beta0))] <- 0
        }
    } else {
        beta0 <- matrix(0, 1, 1)
    }
    result <- list(Y0 = Y0, beta0 = beta0)
    return(result)
}

## cross validation sampling
cv.sample <- function(I, count) {
    N <- dim(I)[2]
    TT <- dim(I)[1]
    cv.id <- NULL
    oci <- which(c(I) == 1)
    if (count <= 3) {
        cv.id <- sample(oci, count, replace = FALSE)   
    } else {
        ## remove boundary observation 
        oci2 <- setdiff(oci, c((1:N)*TT, (TT*(0:(N-1))+1)))
        ## randomly select 1/3
        subcount <- as.integer(count/3)
        rm.id <- sample(oci2, subcount, replace = FALSE)
        rm.id.upper <- rm.id - 1
        rm.id.lower <- rm.id + 1

        cv.id1 <- unique(c(rm.id, rm.id.upper, rm.id.lower))
        pos <- sapply(1:length(cv.id1), function(i) cv.id1[i]%in%oci)
        cv.id1 <- cv.id1[pos]
        if (length(cv.id1) >= count) {
            cv.id1 <- cv.id1[1:count]
            cv.id2 <- NULL
        } else {
            cv.id2 <- sample(setdiff(oci, cv.id1), (count - length(cv.id1)), replace = FALSE)
        }
        cv.id <- sort(c(cv.id1, cv.id2))
    }
    return(cv.id)
}



