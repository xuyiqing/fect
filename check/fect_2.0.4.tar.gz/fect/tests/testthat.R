library(testthat)
library(fect)

test_check("fect")
